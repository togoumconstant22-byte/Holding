import '@fortawesome/fontawesome-free/css/all.min.css';
import React from 'react'; import { createRoot } from 'react-dom/client'; import App from './App.jsx'; import './style.css';
createRoot(document.getElementById('root')).render(<App />);

// Réveille l'API (hébergement gratuit) dès l'ouverture de la page
fetch((import.meta.env.VITE_API_URL || '') + '/api/health').catch(() => { });
