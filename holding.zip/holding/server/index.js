import express from 'express'; import cors from 'cors'; import jwt from 'jsonwebtoken'; import bcrypt from 'bcryptjs'; import fs from 'fs'; import path from 'path'; import { fileURLToPath } from 'url';
import { openStore } from './store.js';
const __dir = path.dirname(fileURLToPath(import.meta.url));
const F = process.env.DATA_FILE || path.join(__dir, 'data.json'), SECRET = process.env.JWT_SECRET || 'changez-moi', PORT = process.env.PORT || 4000;
const seed = { n: 10, users: [{ id: 1, nom: 'Admin', email: 'admin@holding.com', hash: bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'admin123', 8), role: 'admin' }],
  parcels: [], clients: [], drivers: [], expenses: [], pickups: [], claims: [], modifs: [], stock: [], remarks: [], newclients: [], documents: [], notifications: [], lots: [], clotures: [], stockMoves: [],
  zones: [{ id: 4, nom: 'Littoral' }, { id: 5, nom: 'Tchad' }],
  cities: [{ id: 2, ref: 'DLA', nom: 'Douala', zone: 4, kg_simple: 0, kg_cosmetique: 0 }, { id: 3, ref: 'NDJ', nom: "N'Djamena", zone: 5, kg_simple: 2500, kg_cosmetique: 2500 }],
  settings: { nom: 'Holding Services', adresse: 'Douala – Ange Raphaël, avant hôtel le Select', tel1: '+237 687 360 701', tel2: '', email: '', website: '', tva: 0, lot_kg: 32, heure_cloture: '18:00', sms_on: false, mail_on: false,
    sms_tpl: 'Holding Services : votre colis {code} est {statut}.', mail_tpl: 'Bonjour, le colis {code} est maintenant : {statut}.' } };
const store = await openStore({ file: F, key: process.env.APP_KEY || 'app' });
const db = (await store.load()) || {};
for (const k in seed) db[k] ??= seed[k];
db.settings = { ...seed.settings, ...db.settings };
db.cities.forEach(c => { if (c.kg_simple === undefined) c.kg_simple = c.kg_cosmetique = /djamena/i.test(c.nom) ? 2500 : 0; });
// Sauvegarde différée (300 ms) et sérialisée ; vidée proprement à l'arrêt (SIGTERM de Render)
let timer = null, saving = Promise.resolve();
const flush = () => { clearTimeout(timer); timer = null; saving = saving.then(() => store.save(db)).catch(e => console.error('Sauvegarde impossible :', e.message)); return saving; };
const save = () => { if (!timer) timer = setTimeout(flush, 300); };
process.on('SIGTERM', async () => { await flush(); process.exit(0); });
const STATUTS = ['Nouveau colis','Attente de ramassage','Ramassé','Expédié','Reçu','Mise en distribution','En cours','Livré','Refusé','Retourné'];
// Documents : préfixe, partie concernée, parcelles éligibles
const DOC = {
  facture: { pre: 'FCT', dim: 'client', ok: p => !['Refusé', 'Retourné'].includes(p.statut) } };
const TZ = 'Africa/Douala', today = () => new Date().toLocaleDateString('sv-SE', { timeZone: TZ }), sum = (L, k) => L.reduce((a, x) => a + (+x[k] || 0), 0);
const city = p => db.cities.find(c => c.id == p.ville) || {};
// Tarif : poids (kg) x prix au kilo de la ville de destination (Douala -> destination), selon la catégorie
const price = p => { const c = city(p), r = p.categorie === 'cosmetique' ? +c.kg_cosmetique : +c.kg_simple; return Math.round((+p.poids || 0) * (r || 0)); };
const isStaff = r => ['admin', 'agent'].includes(r);
const own = (u, x) => u.role === 'client' ? x.client == u.clientId : u.role === 'livreur' ? x.livreur == u.driverId : true;
const allowed = (role, m, r) => isStaff(role) || (m === 'GET' && r === 'cities') ||
  (role === 'client' && ((r === 'parcels' && ['GET', 'POST'].includes(m)) || (['claims', 'modifs'].includes(r) && ['GET', 'POST'].includes(m)))) || (role === 'livreur' && r === 'parcels' && m === 'GET');
const notify = p => {
  const S = db.settings, fill = t => t.replace('{code}', p.code).replace('{statut}', p.statut), cl = db.clients.find(c => c.id == p.client);
  // Point d'extension : brancher ici un vrai fournisseur SMS / SMTP. Pour l'instant, journalisation.
  if (S.sms_on && p.tel) db.notifications.unshift({ id: ++db.n, date: new Date().toISOString(), canal: 'SMS', to: p.tel, msg: fill(S.sms_tpl) });
  if (S.mail_on && cl?.email) db.notifications.unshift({ id: ++db.n, date: new Date().toISOString(), canal: 'E-mail', to: cl.email, msg: fill(S.mail_tpl) });
};
// Migration : anciens produits (quantité unique) -> produit + mouvement d'entrée
db.stock.forEach(p => { if (p.prix_vente === undefined) { p.prix_vente = +p.prix || 0; p.prix_achat = 0; p.seuil = ''; if (+p.quantite > 0) db.stockMoves.push({ id: ++db.n, produit: p.id, type: 'entree', quantite: +p.quantite, prix_unitaire: 0, date: p.date || today(), note: 'Stock initial' }); delete p.quantite; delete p.prix; } });
// Paiement : à l'agence (départ), à la destination, ou partiel ; modes : espèces, OM, MoMo
const payNorm = p => {
  p.paiement = ['paye_ici', 'destination', 'partiel'].includes(p.paiement) ? p.paiement : 'paye_ici'; const f = +p.frais || 0;
  const ici = p.paiement === 'paye_ici' ? f : p.paiement === 'partiel' ? Math.max(0, Math.min(+p.montant_ici || 0, f)) : 0;
  p.montant_ici = ici; p.montant_dest = f - ici; p.mode ||= 'especes'; p.mode_dest ||= 'especes'; if (!p.montant_dest) delete p.dest_paye;
};
const initParcel = o => { const c = db.cities.find(x => x.id == o.ville); o.code = (c?.ref || 'HS') + Date.now().toString().slice(-6); o.statut = 'Nouveau colis'; o.docs = {}; o.frais = price(o); payNorm(o); o.historique = [{ statut: o.statut, date: new Date().toISOString() }]; };

const app = express(); app.use(cors(), express.json({ limit: '5mb' }));
const auth = (req, res, next) => { try { req.user = jwt.verify((req.headers.authorization || '').slice(7), SECRET); next(); } catch { res.status(401).json({ error: 'Session expirée' }); } };
const only = (...r) => (q, s, n) => r.includes(q.user.role) ? n() : s.status(403).json({ error: 'Accès refusé' });
const staff = only('admin', 'agent'), admin = only('admin');
const gate = r => (q, s, n) => allowed(q.user.role, q.method, r) ? n() : s.status(403).json({ error: 'Accès refusé' });

// --- Public : connexion, inscription client, suivi de colis
app.post('/api/login', (req, res) => {
  const u = db.users.find(x => x.email === req.body.email);
  if (!u || !bcrypt.compareSync(req.body.password || '', u.hash)) return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
  res.json({ token: jwt.sign({ id: u.id, role: u.role, clientId: u.clientId, driverId: u.driverId }, SECRET, { expiresIn: '12h' }), role: u.role, nom: u.nom });
});
app.post('/api/register', (q, s) => {
  const { nom, tel, ville, email, password } = q.body;
  if (!nom || !email || !password) return s.status(400).json({ error: 'Nom, e-mail et mot de passe requis' });
  if (db.users.some(u => u.email === email) || db.newclients.some(n => n.email === email)) return s.status(400).json({ error: 'Cet e-mail est déjà utilisé' });
  db.newclients.unshift({ id: ++db.n, date: today(), nom, tel, ville, email, hash: bcrypt.hashSync(password, 8), etat: 'En attente' }); save(); s.status(201).json({ ok: 1 });
});
app.get('/api/brand', (q, s) => { const { nom, slogan, tel1, tel2, website, adresse } = db.settings; s.json({ nom, slogan, tel1, tel2, website, adresse }); });
app.get('/api/track/:code', (q, s) => {
  const p = db.parcels.find(x => x.code === q.params.code.trim());
  p ? s.json({ code: p.code, statut: p.statut, ville: city(p).nom, historique: p.historique }) : s.status(404).json({ error: 'Colis introuvable' });
});

// --- Utilisateurs, nouveaux clients, paramètres, notifications
const strip = ({ hash, ...u }) => u;
app.get('/api/users', auth, admin, (q, s) => s.json(db.users.map(strip)));
app.post('/api/users', auth, admin, (q, s) => {
  const { password, ...b } = q.body; if (db.users.some(u => u.email === b.email)) return s.status(400).json({ error: 'E-mail déjà utilisé' });
  const u = { ...b, id: ++db.n, hash: bcrypt.hashSync(password || 'changeme', 8) }; db.users.push(u); save(); s.status(201).json(strip(u));
});
app.put('/api/users/:id', auth, admin, (q, s) => {
  const u = db.users.find(x => x.id == q.params.id); if (!u) return s.sendStatus(404);
  const { password, hash, ...b } = q.body; Object.assign(u, b, { id: u.id }); if (password) u.hash = bcrypt.hashSync(password, 8); save(); s.json(strip(u));
});
app.delete('/api/users/:id', auth, admin, (q, s) => { if (q.params.id == q.user.id) return s.status(400).json({ error: 'Impossible de supprimer votre propre compte' }); db.users = db.users.filter(x => x.id != q.params.id); save(); s.sendStatus(204); });
app.get('/api/newclients', auth, staff, (q, s) => s.json(db.newclients.map(strip)));
app.delete('/api/newclients/:id', auth, staff, (q, s) => { db.newclients = db.newclients.filter(x => x.id != q.params.id); save(); s.sendStatus(204); });
app.post('/api/newclients/:id/approve', auth, staff, (q, s) => {
  const n = db.newclients.find(x => x.id == q.params.id); if (!n) return s.sendStatus(404);
  const c = { id: ++db.n, nom: n.nom, tel: n.tel, ville: n.ville, email: n.email, date: today() }; db.clients.unshift(c);
  db.users.push({ id: ++db.n, nom: n.nom, email: n.email, hash: n.hash, role: 'client', clientId: c.id }); n.etat = 'Validé'; save(); s.json(c);
});
app.get('/api/settings', auth, staff, (q, s) => s.json(db.settings));
app.put('/api/settings', auth, admin, (q, s) => { Object.assign(db.settings, q.body); save(); s.json(db.settings); });
app.get('/api/notifications', auth, staff, (q, s) => s.json(db.notifications.slice(0, 200)));
app.get('/api/badges', auth, staff, (q, s) => s.json({ claims: db.claims.filter(c => c.etat === 'Ouverte').length, modifs: db.modifs.filter(c => c.etat === 'En attente').length,
  lots: db.lots.filter(l => l.etat === 'À emballer').length, newclients: db.newclients.filter(c => c.etat === 'En attente').length }));

// --- Documents (bons, factures)
const eligible = (type, partie) => { const d = DOC[type]; return d ? db.parcels.filter(p => p[d.dim] == partie && d.ok(p) && !p.docs?.[type]) : []; };
app.get('/api/documents', auth, staff, (q, s) => s.json(db.documents.filter(d => !q.query.type || d.type === q.query.type)));
app.get('/api/documents/eligible', auth, staff, (q, s) => s.json(eligible(q.query.type, q.query.partie)));
app.get('/api/documents/:id', auth, staff, (q, s) => {
  const d = db.documents.find(x => x.id == q.params.id); if (!d) return s.sendStatus(404);
  s.json({ doc: d, parcels: d.parcelIds.map(i => db.parcels.find(p => p.id == i)).filter(Boolean).map(p => ({ ...p, fraisCalc: p.frais })) });
});
app.post('/api/documents', auth, staff, (q, s) => {
  const { type, partie, ids } = q.body, def = DOC[type], L = eligible(type, partie).filter(p => !ids || ids.includes(p.id));
  if (!def || !L.length) return s.status(400).json({ error: 'Aucun colis éligible pour ce document' });
  const montant = sum(L, 'frais'), tva = +db.settings.tva || 0;
  const d = { id: ++db.n, type, partie, date: today(), statut: 'Non payé', parcelIds: L.map(p => p.id), colis: L.length, poids: sum(L, 'poids'), montant, tva, total: Math.round(montant * (1 + tva / 100)) };
  const dt = d.date.slice(8) + d.date.slice(5, 7) + d.date.slice(2, 4); d.ref = `${def.pre}-${dt}-${d.id}`;
  L.forEach(p => (p.docs ||= {})[type] = d.ref); db.documents.unshift(d); save(); s.status(201).json(d);
});
app.patch('/api/documents/:id/statut', auth, staff, (q, s) => { const d = db.documents.find(x => x.id == q.params.id); if (!d) return s.sendStatus(404); d.statut = q.body.statut === 'Payé' ? 'Payé' : 'Non payé'; save(); s.json(d); });
app.delete('/api/documents/:id', auth, staff, (q, s) => {
  const d = db.documents.find(x => x.id == q.params.id); if (d) d.parcelIds.forEach(i => { const p = db.parcels.find(x => x.id == i); if (p?.docs) delete p.docs[d.type]; });
  db.documents = db.documents.filter(x => x.id != q.params.id); save(); s.sendStatus(204);
});

// --- Colis : statut, modifications
app.patch('/api/parcels/:id/statut', auth, (q, s) => {
  const p = db.parcels.find(x => x.id == q.params.id);
  if (!p || !STATUTS.includes(q.body.statut)) return s.status(400).json({ error: 'Statut invalide' });
  if (!isStaff(q.user.role) && !(q.user.role === 'livreur' && p.livreur == q.user.driverId)) return s.status(403).json({ error: 'Accès refusé' });
  p.statut = q.body.statut; if (p.statut === 'Livré') p.livre_le = today(); else delete p.livre_le; (p.historique ||= []).push({ statut: p.statut, date: new Date().toISOString() }); notify(p); updateLots(); save(); s.json(p);
});
app.post('/api/modifs/:id/decision', auth, staff, (q, s) => {
  const m = db.modifs.find(x => x.id == q.params.id); if (!m) return s.sendStatus(404);
  m.etat = q.body.decision === 'Approuvée' ? 'Approuvée' : 'Refusée';
  if (m.etat === 'Approuvée') { const p = db.parcels.find(x => x.code === m.code); if (p && ['dest', 'tel', 'prix'].includes(m.champ)) p[m.champ] = m.valeur; }
  save(); s.json(m);
});

// --- Gestion de stock : produits, mouvements (entrées / sorties), calculs et rapport
const nn = v => +v || 0;
const calcStock = q => db.stock.filter(p => !q.client || p.client == q.client).map(p => {
  const M = db.stockMoves.filter(m => m.produit == p.id), qty = (L, t) => L.filter(m => m.type === t).reduce((a, m) => a + nn(m.quantite), 0);
  const before = q.from ? M.filter(m => m.date < q.from) : [], per = M.filter(m => (!q.from || m.date >= q.from) && (!q.to || m.date <= q.to));
  const ouverture = qty(before, 'entree') - qty(before, 'sortie'), entrees = qty(per, 'entree'), sorties = qty(per, 'sortie'), restant = ouverture + entrees - sorties;
  const ventes = per.filter(m => m.type === 'sortie'), ca = ventes.reduce((a, m) => a + nn(m.quantite) * nn(m.prix_unitaire), 0), cout = ventes.reduce((a, m) => a + nn(m.quantite) * nn(p.prix_achat), 0);
  return { ...p, ouverture, entrees, sorties, restant, ca, cout, marge: ca - cout, valeur_restante: restant * nn(p.prix_vente), alerte: p.seuil !== '' && p.seuil != null && restant <= nn(p.seuil) };
});
const stockTot = L => Object.fromEntries(['ouverture', 'entrees', 'sorties', 'restant', 'ca', 'cout', 'marge', 'valeur_restante'].map(k => [k, L.reduce((a, p) => a + nn(p[k]), 0)]));
const stockRest = id => db.stockMoves.filter(m => m.produit == id).reduce((a, m) => a + (m.type === 'entree' ? 1 : -1) * nn(m.quantite), 0);
app.get('/api/stock', auth, staff, (q, s) => { const L = calcStock(q.query); s.json({ produits: L, totaux: stockTot(L) }); });
app.get('/api/stock/moves', auth, staff, (q, s) => s.json(db.stockMoves.filter(m => (!q.query.produit || m.produit == q.query.produit) && (!q.query.type || m.type === q.query.type) && inR(m.date, q.query))
  .sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id).map(m => ({ ...m, nom: db.stock.find(p => p.id == m.produit)?.produit || '(supprimé)' }))));
app.post('/api/stock/moves', auth, staff, (q, s) => {
  const b = q.body, p = db.stock.find(x => x.id == b.produit), qte = nn(b.quantite), type = b.type === 'sortie' ? 'sortie' : 'entree';
  if (!p) return s.status(400).json({ error: 'Produit introuvable' }); if (qte <= 0) return s.status(400).json({ error: 'Quantité invalide' });
  if (type === 'sortie' && qte > stockRest(p.id)) return s.status(400).json({ error: `Stock insuffisant (restant : ${stockRest(p.id)})` });
  const pu = b.prix_unitaire !== '' && b.prix_unitaire != null ? nn(b.prix_unitaire) : nn(type === 'sortie' ? p.prix_vente : p.prix_achat);
  const m = { id: ++db.n, produit: p.id, type, quantite: qte, prix_unitaire: pu, date: b.date || today(), note: b.note || '' }; db.stockMoves.unshift(m); save(); s.status(201).json(m);
});
app.delete('/api/stock/moves/:id', auth, staff, (q, s) => { db.stockMoves = db.stockMoves.filter(m => m.id != q.params.id); save(); s.sendStatus(204); });
app.get('/api/stock/report', auth, staff, (q, s) => {
  const Q = { ...q.query }; if (Q.period) { const [f, t] = range(['day', 'week', 'month'].includes(Q.period) ? Q.period : 'day', Q.date || today()); Q.from = f; Q.to = t; }
  const L = calcStock(Q); s.json({ from: Q.from || '', to: Q.to || '', produits: L, totaux: stockTot(L), alertes: L.filter(p => p.alerte).map(p => ({ id: p.id, produit: p.produit, restant: p.restant, seuil: p.seuil })) });
});
app.post('/api/stock', auth, staff, (q, s) => {
  const b = q.body, p = { id: ++db.n, produit: String(b.produit || '').trim(), client: b.client || '', prix_achat: nn(b.prix_achat), prix_vente: nn(b.prix_vente), seuil: b.seuil === '' || b.seuil == null ? '' : nn(b.seuil), date: today() };
  if (!p.produit) return s.status(400).json({ error: 'Nom du produit requis' }); db.stock.unshift(p);
  if (nn(b.quantite_initiale) > 0) db.stockMoves.unshift({ id: ++db.n, produit: p.id, type: 'entree', quantite: nn(b.quantite_initiale), prix_unitaire: p.prix_achat, date: today(), note: 'Stock initial' });
  save(); s.status(201).json(p);
});
app.put('/api/stock/:id', auth, staff, (q, s) => {
  const p = db.stock.find(x => x.id == q.params.id); if (!p) return s.sendStatus(404); const b = q.body;
  Object.assign(p, { produit: String(b.produit ?? p.produit).trim(), client: b.client ?? p.client, prix_achat: nn(b.prix_achat), prix_vente: nn(b.prix_vente), seuil: b.seuil === '' || b.seuil == null ? '' : nn(b.seuil) }); save(); s.json(p);
});
app.delete('/api/stock/:id', auth, staff, (q, s) => { db.stock = db.stock.filter(p => p.id != q.params.id); db.stockMoves = db.stockMoves.filter(m => m.produit != q.params.id); save(); s.sendStatus(204); });

// --- CRUD générique
for (const r of ['parcels', 'clients', 'cities', 'drivers', 'expenses', 'claims', 'modifs', 'zones']) {
  app.get(`/api/${r}`, auth, gate(r), (q, s) => s.json(db[r].filter(x => own(q.user, x))));
  app.post(`/api/${r}`, auth, gate(r), (q, s) => {
    const o = { date: today(), ...q.body, id: ++db.n }; if (q.user.role === 'client') o.client = q.user.clientId;
    if (r === 'parcels') { const c = db.clients.find(x => x.id == o.client); o.exp_nom ||= c?.nom; o.exp_tel ||= c?.tel; o.exp_ville ||= c?.ville; } // expéditeur par défaut = le client
    if (r === 'parcels') initParcel(o); if (r === 'claims') o.etat ||= 'Ouverte'; if (r === 'modifs') o.etat = 'En attente'; 
    db[r].unshift(o); if (r === 'parcels') updateLots(); save(); s.status(201).json(o);
  });
  app.put(`/api/${r}/:id`, auth, gate(r), (q, s) => {
    const o = db[r].find(x => x.id == q.params.id); if (!o) return s.sendStatus(404);
    Object.assign(o, q.body, { id: o.id }); if (r === 'parcels') { o.frais = price(o); payNorm(o); updateLots(); } save(); s.json(o);
  });
  app.delete(`/api/${r}/:id`, auth, gate(r), (q, s) => { db[r] = db[r].filter(x => x.id != q.params.id); save(); s.sendStatus(204); });
}

// --- Tas de poids (32 kg par défaut) : alerte aux employés pour emballer et compter
const PEND = ['Nouveau colis', 'Attente de ramassage', 'Ramassé'];
const updateLots = () => {
  const lim = +db.settings.lot_kg || 32;
  for (const c of db.cities) {
    let acc = [], w = 0;
    for (const p of db.parcels.filter(p => p.ville == c.id && !p.lot && PEND.includes(p.statut)).sort((a, b) => a.id - b.id)) {
      acc.push(p); w += +p.poids || 0;
      if (w >= lim) {
        const l = { id: ++db.n, date: today(), ville: c.id, poids: Math.round(w * 100) / 100, colis: acc.length, parcelIds: acc.map(x => x.id), etat: 'À emballer' };
        acc.forEach(x => x.lot = l.id); db.lots.unshift(l);
        db.notifications.unshift({ id: ++db.n, date: new Date().toISOString(), canal: 'Alerte employés', to: 'Équipe emballage', msg: `${l.poids} kg atteints pour ${c.nom} (${l.colis} colis) : emballer et compter le tas n°${l.id}.` });
        acc = []; w = 0;
      }
    }
  }
};
app.get('/api/lots', auth, staff, (q, s) => s.json({ limit: +db.settings.lot_kg || 32, lots: db.lots,
  pending: db.cities.map(c => ({ ville: c.id, nom: c.nom, poids: sum(db.parcels.filter(p => p.ville == c.id && !p.lot && PEND.includes(p.statut)), 'poids') })).filter(x => x.poids > 0) }));
app.patch('/api/lots/:id', auth, staff, (q, s) => { const l = db.lots.find(x => x.id == q.params.id); if (!l) return s.sendStatus(404); l.etat = 'Emballé'; l.emballe_le = today(); save(); s.json(l); });

// --- Statistiques (filtres période / client / livreur / ville / zone)
const inR = (d, q) => (!q.from || d >= q.from) && (!q.to || d <= q.to);
const zoneOf = p => city(p).zone;
const sel = (q, u) => db.parcels.filter(p => own(u, p) && inR(p.date, q) && (!q.client || p.client == q.client) && (!q.livreur || p.livreur == q.livreur) && (!q.ville || p.ville == q.ville) && (!q.zone || zoneOf(p) == q.zone));
const fin = L => { const l = L.filter(p => p.statut === 'Livré'); return { ca: sum(l, 'frais'), poids: sum(l, 'poids') }; };
app.get('/api/stats', auth, (q, s) => {
  const Q = q.query, L = sel(Q, q.user), st = isStaff(q.user.role), f = fin(L);
  const grp = t => Object.fromEntries(['Non payé', 'Payé'].map(k => { const D = db.documents.filter(d => d.type === t && d.statut === k && inR(d.date, Q)); return [k, { n: D.length, colis: sum(D, 'colis'), montant: sum(D, 'montant'), total: sum(D, 'total') }]; }));
  const dep = st ? sum(db.expenses.filter(e => inR(e.date, Q)), 'montant') : 0;
  s.json({ total: L.length, parStatut: Object.fromEntries(STATUTS.map(t => [t, L.filter(p => p.statut === t).length])), ...f, depenses: dep, benefice: f.ca - dep,
    docs: st ? { facture: grp('facture') } : null,
    docCount: st ? Object.fromEntries(Object.keys(DOC).map(t => [t, db.documents.filter(d => d.type === t).length])) : {},
    counts: st ? { clients: db.clients.length, claims: db.claims.length, modifs: db.modifs.length } : {} });
});
app.get('/api/stats/compare', auth, staff, (q, s) => {
  const dim = q.query.dim, src = { client: db.clients, livreur: db.drivers, ville: db.cities, zone: db.zones }[dim] || [];
  s.json(src.map(e => { const L = sel({ ...q.query, [dim]: e.id }, q.user); const c = t => L.filter(p => p.statut === t).length;
    return { id: e.id, nom: e.nom, total: L.length, livre: c('Livré'), refuse: c('Refusé'), retourne: c('Retourné'), ...fin(L) }; }));
});

// --- Finance : colis envoyés / en cours / restants, encaissements, dépenses
const ST_NON = ['Nouveau colis', 'Attente de ramassage', 'Ramassé'], ST_COURS = ['Expédié', 'Reçu', 'Mise en distribution', 'En cours'], ST_KO = ['Refusé', 'Retourné'];
const encaisse = p => (+p.montant_ici || 0) + (p.dest_paye ? +p.montant_dest || 0 : 0);
const grp = L => ({ colis: L.length, poids: sum(L, 'poids'), montant: sum(L, 'frais') });
app.patch('/api/parcels/:id/dest-paye', auth, staff, (q, s) => {
  const p = db.parcels.find(x => x.id == q.params.id); if (!p) return s.sendStatus(404);
  p.dest_paye = q.body.paye !== false; p.dest_paye_le = p.dest_paye ? today() : undefined; save(); s.json(p);
});
app.get('/api/finance', auth, staff, (q, s) => {
  const Q = { ...q.query }; if (!Q.to) Q.to = today();
  if (Q.all) { Q.from = [...db.parcels.map(p => p.date), ...db.expenses.map(e => e.date)].filter(Boolean).sort()[0] || Q.to; }
  else if (!Q.from) { const x = new Date(Q.to + 'T12:00:00Z'); x.setUTCDate(x.getUTCDate() - 29); Q.from = iso(x); }
  const P = db.parcels.filter(p => inR(p.date, Q)), ok = P.filter(p => !ST_KO.includes(p.statut)), dep = db.expenses.filter(e => inR(e.date, Q));
  const ca = sum(ok, 'frais'), enc = ok.reduce((a, p) => a + encaisse(p), 0), totDep = sum(dep, 'montant');
  const liv = P.filter(p => p.statut === 'Livré'), cours = P.filter(p => ST_COURS.includes(p.statut)), non = P.filter(p => ST_NON.includes(p.statut));
  const modes = {}; ok.forEach(p => { if (+p.montant_ici) modes[p.mode || 'especes'] = (modes[p.mode || 'especes'] || 0) + +p.montant_ici; if (p.dest_paye && +p.montant_dest) { const m = p.mode_dest || 'especes'; modes[m] = (modes[m] || 0) + +p.montant_dest; } });
  const days = Math.round((new Date(Q.to) - new Date(Q.from)) / 864e5) + 1, key = d => days > 92 ? d.slice(0, 7) : d, map = {};
  const add = (k, f, v) => { (map[k] ||= { k, ca: 0, enc: 0, dep: 0 })[f] += v; };
  if (days <= 62) for (let i = 0; i < days; i++) { const x = new Date(Q.from + 'T12:00:00Z'); x.setUTCDate(x.getUTCDate() + i); add(iso(x), 'ca', 0); }
  ok.forEach(p => { add(key(p.date), 'ca', +p.frais || 0); add(key(p.date), 'enc', encaisse(p)); }); dep.forEach(e => add(key(e.date), 'dep', +e.montant || 0));
  const parCat = {}; dep.forEach(e => { const c = e.categorie || 'Autre'; parCat[c] = (parCat[c] || 0) + (+e.montant || 0); });
  s.json({ from: Q.from, to: Q.to, groupes: { expedies: grp([...liv, ...cours]), livres: grp(liv), cours: grp(cours), non: grp(non), ko: grp(P.filter(p => ST_KO.includes(p.statut))), total: grp(ok) },
    ca, encaisse: enc, reste: ca - enc, depenses: totDep, net: enc - totDep, previsionnel: ca - totDep, modes, parCategorie: parCat,
    series: Object.values(map).sort((a, b) => a.k.localeCompare(b.k)),
    clients: db.clients.map(c => { const L = ok.filter(p => p.client == c.id), t = sum(L, 'frais'), e = L.reduce((a, p) => a + encaisse(p), 0); return { id: c.id, nom: c.nom, colis: L.length, total: t, encaisse: e, reste: t - e }; }).filter(c => c.colis).sort((a, b) => b.reste - a.reste),
    villes: db.cities.map(c => ({ nom: c.nom, ...grp(ok.filter(p => p.ville == c.id)) })).filter(c => c.colis),
    aEncaisserDest: ok.filter(p => +p.montant_dest > 0 && !p.dest_paye).map(p => ({ id: p.id, code: p.code, client: db.clients.find(c => c.id == p.client)?.nom || '-', ville: city(p).nom, montant: p.montant_dest, mode: p.mode_dest, statut: p.statut })),
    depensesListe: [...dep].sort((a, b) => b.date.localeCompare(a.date)) });
});

// --- Rapports jour / semaine / mois et clôture journalière
const iso = x => x.toISOString().slice(0, 10);
const range = (period, d) => {
  const x = new Date(d + 'T12:00:00Z'); if (period === 'day') return [d, d];
  if (period === 'week') { const a = new Date(x); a.setUTCDate(x.getUTCDate() - (x.getUTCDay() + 6) % 7); const b = new Date(a); b.setUTCDate(a.getUTCDate() + 6); return [iso(a), iso(b)]; }
  return [iso(new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth(), 1))), iso(new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth() + 1, 0)))];
};
const livreLe = p => p.livre_le || (p.statut === 'Livré' ? (p.historique || []).filter(h => h.statut === 'Livré').pop()?.date?.slice(0, 10) : undefined);
const report = (period, date) => {
  const [from, to] = range(period, date), inr = d => d && d >= from && d <= to, liv = db.parcels.filter(p => p.statut === 'Livré' && inr(livreLe(p)));
  const row = (id, nom, L) => ({ id, nom, colis: L.length, poids: sum(L, 'poids'), montant: sum(L, 'frais') });
  const parClient = db.clients.map(c => row(c.id, c.nom, liv.filter(p => p.client == c.id))).filter(r => r.colis);
  const sans = liv.filter(p => !db.clients.some(c => c.id == p.client)); if (sans.length) parClient.push(row(0, 'Sans client', sans));
  const montant = sum(liv, 'frais'), dep = sum(db.expenses.filter(e => inr(e.date)), 'montant');
  return { period, from, to, livres: liv.length, poids: sum(liv, 'poids'), montant, crees: db.parcels.filter(p => inr(p.date)).length, encaisse: db.parcels.filter(p => inr(p.date) && !ST_KO.includes(p.statut)).reduce((a, p) => a + encaisse(p), 0), depenses: dep, benefice: montant - dep, emballes: db.lots.filter(l => inr(l.date)).length, parClient };
};
const cloture = d => {
  const r = report('day', d); db.clotures = db.clotures.filter(x => x.date !== d); db.clotures.unshift({ id: ++db.n, date: d, ...r });
  db.notifications.unshift({ id: ++db.n, date: new Date().toISOString(), canal: 'Clôture', to: 'Direction', msg: `Clôture du ${d} : ${r.livres} colis livrés, ${r.poids} kg, total ${r.montant} FCFA.` }); save(); return r;
};
app.get('/api/reports', auth, staff, (q, s) => s.json(report(['day', 'week', 'month'].includes(q.query.period) ? q.query.period : 'day', q.query.date || today())));
app.get('/api/clotures', auth, staff, (q, s) => s.json(db.clotures));
app.post('/api/clotures', auth, staff, (q, s) => s.json(cloture(q.body.date || today())));
setInterval(() => { // clôture automatique à l'heure définie dans les paramètres
  const hm = new Date().toLocaleTimeString('fr-FR', { timeZone: TZ, hour: '2-digit', minute: '2-digit' });
  if (hm === db.settings.heure_cloture && !db.clotures.some(c => c.date === today())) cloture(today());
}, 30000);
app.get('/api/health', (q, w) => w.json({ ok: true }));
// Production : le serveur sert aussi l'interface React compilée (client/dist)
const DIST = path.join(__dir, '../client/dist');
if (fs.existsSync(DIST)) { app.use(express.static(DIST)); app.get(/^\/(?!api).*/, (q, s) => s.sendFile(path.join(DIST, 'index.html'))); }
if (!process.env.JWT_SECRET) console.warn('ATTENTION : définissez la variable JWT_SECRET en production.');
app.listen(PORT, '0.0.0.0', () => console.log(`Holding Services démarré sur le port ${PORT}`));
