// Stockage : PostgreSQL si DATABASE_URL est défini (Render + Neon/Supabase), sinon fichier JSON local.
import fs from 'fs';
export async function openStore({ file, key }) {
  const url = process.env.DATABASE_URL;
  if (!url) return {
    load: async () => (fs.existsSync(file) ? JSON.parse(fs.readFileSync(file)) : null),
    save: async db => fs.writeFileSync(file, JSON.stringify(db, null, 1)) };
  const { default: pg } = await import('pg');
  const local = /localhost|127\.0\.0\.1|host=\//.test(url);
  const pool = new pg.Pool({ connectionString: url, ssl: local ? undefined : { rejectUnauthorized: false }, max: 3 });
  await pool.query('CREATE TABLE IF NOT EXISTS kv (key text PRIMARY KEY, value jsonb NOT NULL, updated_at timestamptz DEFAULT now())');
  console.log('Stockage PostgreSQL actif (clé : ' + key + ')');
  return {
    load: async () => (await pool.query('SELECT value FROM kv WHERE key = $1', [key])).rows[0]?.value || null,
    save: async db => { await pool.query('INSERT INTO kv(key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = $2, updated_at = now()', [key, JSON.stringify(db)]); } };
}
