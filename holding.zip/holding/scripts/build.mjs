// L'interface est déjà compilée dans client/dist : on ne recompile que si elle est absente.
import fs from 'fs'; import { execSync } from 'child_process';
if (fs.existsSync('client/dist/index.html')) console.log('Interface déjà compilée (client/dist) : build ignoré.');
else { execSync('npm --prefix client install --include=dev', { stdio: 'inherit' }); execSync('npm --prefix client run build', { stdio: 'inherit' }); }
