# Holding Services – Gestion des colis (React + Node.js)
## Démarrage
1. `npm run install:all`
2. Terminal 1 : `npm run dev:server` (API :4000, données dans server/data.json)
3. Terminal 2 : `npm run dev:client` (http://localhost:5173)
Connexion : admin@holding.com / admin123 (à changer ; définir JWT_SECRET en production).

## Règles métier
- Tarif : poids (kg) × prix au kilo de la ville de destination (Villes & tarifs), par catégorie (produit simple / cosmétique). Douala → N'Djamena : 2 500 FCFA/kg.
- Tas : dès que le poids cumulé des colis non expédiés d'une destination atteint le seuil (32 kg, modifiable), un tas « À emballer » est créé et une alerte s'affiche à l'équipe (bandeau + notifications).
- Clôture : chaque jour à l'heure réglée (18:00 par défaut, fuseau Africa/Douala), colis livrés et montant par client sont enregistrés (le serveur doit être démarré). Bouton « Clôturer » manuel dans Rapports.
- Rapports jour / semaine / mois imprimables. Factures professionnelles (TVA réglable) avec nom, adresse et téléphones de l'agence.
## Évolutions
SMS/e-mails (brancher un fournisseur dans notify()), base MySQL/PostgreSQL à la place de data.json.

## Paiement des colis
À l'enregistrement : payé à l'agence, à payer à la destination, ou partiel (montant ici + reste à destination), avec mode Espèces / OM / MoMo pour chaque part. Le montant encaissé à destination se marque dans Finance ou dans la liste des colis.
## Finance
Colis expédiés / en cours / non envoyés (nombre, poids, montant), chiffre d'affaires, encaissé, reste à encaisser, dépenses (ajout et suppression dans la page), résultat net et prévisionnel, encaissements par mode, créances par client, graphique d'évolution.
## Factures
Générées par client (colis au choix) ou en un clic depuis un colis ; elles détaillent la modalité de paiement, le payé à l'agence, le reste à payer à la destination et les modes acceptés.
