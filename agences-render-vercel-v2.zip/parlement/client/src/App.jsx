import { useState, useEffect, useCallback } from 'react';
import QRCode from 'qrcode';
const STATUTS = ['Nouveau colis','Attente de ramassage','Ramassé','Expédié','Reçu','Mise en distribution','En cours','Livré','Refusé','Retourné'];
const api = async (path, method = 'GET', body) => {
  const r = await fetch((import.meta.env.VITE_API_URL || '') + '/api' + path, { method, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + localStorage.getItem('tk') }, body: body && JSON.stringify(body) });
  if (r.status === 401 && !['/login', '/register'].includes(path) && localStorage.getItem('tk')) { localStorage.clear(); location.reload(); }
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'Erreur serveur');
  return r.status === 204 ? null : r.json();
};
const money = n => (+n || 0).toLocaleString('fr-FR') + ' FCFA';
const role = () => localStorage.getItem('role'), staff = () => ['admin', 'agent'].includes(role());
const f = x => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
const nameOf = (D, res, id) => D[res]?.find(x => x.id == id)?.nom || '-';
const PRESETS = ['Depuis le lancement', "Aujourd'hui", '7 derniers jours', '30 derniers jours', 'Ce mois', 'Le mois dernier'];
function rng(p) { const d = new Date(), t = f(d), b = n => { const x = new Date(); x.setDate(x.getDate() - n); return f(x); };
  return p === PRESETS[1] ? [t, t] : p === PRESETS[2] ? [b(7), t] : p === PRESETS[3] ? [b(30), t] : p === PRESETS[4] ? [f(new Date(d.getFullYear(), d.getMonth(), 1)), t]
    : p === PRESETS[5] ? [f(new Date(d.getFullYear(), d.getMonth() - 1, 1)), f(new Date(d.getFullYear(), d.getMonth(), 0))] : ['', '']; }
const Range = ({ v, set }) => <select value={v.p} onChange={e => { const [from, to] = rng(e.target.value); set({ ...v, p: e.target.value, from, to }); }}>{PRESETS.map(p => <option key={p}>{p}</option>)}</select>;
const DOCS = [['facture', 'Factures', 'client']];
const DIMRES = { client: 'clients', livreur: 'drivers', ville: 'cities', zone: 'zones' };
const ROLES = [['admin', 'Administrateur'], ['agent', 'Agent'], ['livreur', 'Livreur'], ['client', 'Client']];
// Modules CRUD : champs [clé, libellé, type, ressource|options, facultatif]
const CFG = {
  parcels: { label: 'Colis', cols: ['code', 'date', 'client', 'dest', 'ville', 'poids', 'frais', 'paiement', 'docs', 'statut'], fields: [['client', 'Client', 'ref', 'clients'], ['dest', 'Destinataire'], ['tel', 'Téléphone'], ['ville', 'Ville de destination', 'ref', 'cities'], ['poids', 'Poids (kg)', 'number'], ['categorie', 'Catégorie', 'sel', [['simple', 'Produit simple'], ['cosmetique', 'Produit cosmétique']]],
    ['exp_nom', 'Expéditeur : nom (par défaut : le client)', 'text', 0, 1], ['exp_tel', 'Expéditeur : téléphone', 'text', 0, 1], ['adresse_dest', 'Adresse du destinataire', 'text', 0, 1], ['contenu', 'Nature du contenu', 'text', 0, 1],
    ['paiement', 'Paiement des frais', 'sel', [['paye_ici', "Payé à l'agence (au départ)"], ['destination', 'À payer à la destination'], ['partiel', "Partiel : une partie ici, le reste à la destination"]]],
    ['montant_ici', "Montant payé à l'agence (FCFA)", 'number', 0, 0, v => v.paiement === 'partiel'],
    ['mode', "Mode de paiement à l'agence", 'sel', [['especes', 'Espèces'], ['om', 'Orange Money (OM)'], ['momo', 'MTN MoMo (MOMO)']], 0, v => v.paiement !== 'destination'],
    ['mode_dest', 'Mode de paiement à la destination', 'sel', [['especes', 'Espèces'], ['om', 'Orange Money (OM)'], ['momo', 'MTN MoMo (MOMO)']], 0, v => v.paiement !== 'paye_ici']] },
  clients: { label: 'Clients', cols: ['nom', 'tel', 'ville', 'email'], fields: [['nom', 'Nom / boutique'], ['tel', 'Téléphone'], ['ville', 'Ville'], ['email', 'E-mail', 'email', 0, 1]] },
  cities: { label: 'Villes & tarifs', cols: ['ref', 'nom', 'zone', 'trajet', 'kg_simple', 'kg_cosmetique'], fields: [['ref', 'Réf'], ['nom', 'Ville'], ['zone', 'Zone', 'ref', 'zones', 1], ['kg_simple', 'Tarif produits simples (FCFA/kg depuis Douala)', 'number'], ['kg_cosmetique', 'Tarif produits cosmétiques (FCFA/kg depuis Douala)', 'number']] },
  zones: { label: 'Zones', cols: ['nom'], fields: [['nom', 'Nom de la zone']] },
  drivers: { label: 'Livreurs', cols: ['nom', 'tel'], fields: [['nom', 'Nom'], ['tel', 'Téléphone']] },
  claims: { label: 'Réclamations', cols: ['code', 'objet', 'date', 'etat'], fields: [['code', 'Code du colis'], ['objet', 'Objet']] },
  modifs: { label: 'Modification colis', cols: ['code', 'champ', 'valeur', 'date', 'etat'], fields: [['code', 'Code du colis'], ['champ', 'Champ à modifier', 'sel', [['dest', 'Destinataire'], ['tel', 'Téléphone'], ['prix', 'Prix']]], ['valeur', 'Nouvelle valeur']] },
  newclients: { label: 'Nouveaux clients', cols: ['nom', 'tel', 'ville', 'email', 'date', 'etat'], fields: [] },
  users: { label: 'Utilisateurs', cols: ['nom', 'email', 'role', 'clientId', 'driverId'], fields: [['nom', 'Nom'], ['email', 'E-mail', 'email'], ['password', 'Mot de passe', 'password', 0, 1], ['role', 'Rôle', 'sel', ROLES], ['clientId', 'Client lié', 'ref', 'clients', 1], ['driverId', 'Livreur lié', 'ref', 'drivers', 1]] },
};
const ETAT = { claims: ['Ouverte', 'Traitée'] };
const LAB = { etat: 'État', docs: 'Documents', trajet: 'Trajet', kg_simple: 'Produits simples', kg_cosmetique: 'Produits cosmétiques', frais: 'Frais (FCFA)', categorie: 'Catégorie', paiement: 'Paiement' };
const MS = { especes: 'Espèces', om: 'OM', momo: 'MoMo' };
const MONEY = ['prix', 'montant', 'frais'];
const TONES = { red: '#dc2626', brand: '#e8761c', blue: '#2563eb', green: '#16a34a', amber: '#d97706', violet: '#7c3aed', slate: '#475569' };
const SCOL = { 'Nouveau colis': '#2563eb', 'Attente de ramassage': '#d97706', 'Ramassé': '#b45309', 'Expédié': '#7c3aed', 'Reçu': '#0e7490', 'Mise en distribution': '#0891b2', 'En cours': '#ea580c', 'Livré': '#16a34a', 'Refusé': '#dc2626', 'Retourné': '#7f1d1d' };
const MENU = [['home', 'Accueil', 0, 'fa-house'], ['clients', 'Clients', 's', 'fa-users'], ['parcels', 'Colis', 0, 'fa-box'], ['doc:facture', 'Factures', 's', 'fa-file-invoice-dollar'], ['finance', 'Finance', 's', 'fa-wallet'],
  ['lots', 'Tas à emballer', 's', 'fa-boxes-packing'], ['reports', 'Rapports', 's', 'fa-file-lines'], ['stats', 'Statistiques', 's', 'fa-chart-pie'], ['newclients', 'Nouveaux clients', 's', 'fa-user-plus'],
  ['claims', 'Réclamations', 0, 'fa-triangle-exclamation'], ['modifs', 'Modification colis', 0, 'fa-pen-to-square'], ['stock', 'Gestion de stock', 's', 'fa-warehouse'], ['etat', 'État colis', 0, 'fa-location-dot'],
  ['drivers', 'Livreurs', 's', 'fa-truck'], ['cities', 'Villes & tarifs', 's', 'fa-city'], ['zones', 'Zones', 's', 'fa-map'], ['users', 'Utilisateurs', 'a', 'fa-user-gear'], ['settings', 'Paramètres', 'a', 'fa-gear'], ['notifs', 'Notifications', 's', 'fa-bell']];
const visible = m => !m[2] || (m[2] === 's' ? staff() : role() === 'admin');
const loadList = () => role() === 'client' ? ['parcels', 'cities', 'claims', 'modifs'] : role() === 'livreur' ? ['parcels', 'cities'] :
  ['parcels', 'clients', 'cities', 'drivers', 'claims', 'modifs', 'zones', 'newclients', ...(role() === 'admin' ? ['users'] : [])];

function Track() {
  const [code, setCode] = useState(''), [r, setR] = useState(null), [err, setErr] = useState('');
  const go = async e => { e.preventDefault(); setErr(''); setR(null); try { setR(await api('/track/' + encodeURIComponent(code.trim()))); } catch (x) { setErr(x.message); } };
  return <div><form className="bar" onSubmit={go}><input placeholder="Code du colis" value={code} onChange={e => setCode(e.target.value)} required /><button className="p">Suivre</button></form>
    {err && <span className="err">{err}</span>}
    {r && <div className="card"><b>{r.code}</b> · {r.ville} · statut actuel : <b>{r.statut}</b><ul className="tl">{r.historique.map((h, i) => <li key={i}>{h.statut} – {new Date(h.date).toLocaleString('fr-FR')}</li>)}</ul></div>}</div>;
}

const Logo = ({ size = 40 }) => <span className="logo" style={{ width: size, height: size, fontSize: size * .62 }}><b>P</b></span>;
const Wordmark = ({ light }) => <span className={'wm' + (light ? ' lt' : '')}><b>PARLEMENT</b><small>●●● Service</small></span>;
const SERV = [['fa-plane', 'Fret aérien'], ['fa-ship', 'Fret maritime'], ['fa-truck-fast', 'Expédition routière en mode Chrono'], ['fa-ticket', 'Billetterie (avion, bus, train)'], ['fa-building', 'Appartements meublés'], ['fa-cart-shopping', 'Achat sur commande']];
function Login({ onOk }) {
  const [tab, setTab] = useState('in'), [v, setV] = useState({}), [err, setErr] = useState(''), [busy, setBusy] = useState(false), set = k => e => setV({ ...v, [k]: e.target.value });
  const go = async e => { e.preventDefault(); setErr(''); setBusy(true);
    try { if (tab === 'in') { const r = await api('/login', 'POST', v); localStorage.setItem('tk', r.token); localStorage.setItem('role', r.role); onOk(); }
      else { await api('/register', 'POST', v); setErr('ok'); } } catch (x) { setErr(x.message); } setBusy(false); };
  const T = { in: ['Connexion', 'Accédez à votre espace de gestion'], reg: ['Devenir client', 'Créez votre compte client Parlement Service'], trk: ['Suivre un colis', 'Saisissez le code de votre colis'] }[tab];
  return <div className="lg"><section className="lg-l"><div className="lg-brand"><Wordmark light /></div><small className="lg-tag">Là où vos échanges internationaux font loi</small>
    <h1>On expédie quoi <span>aujourd'hui, boss ?</span></h1><p className="lg-p">Du fret aérien au maritime, en passant par le routier, nous connectons le monde à vos ambitions.</p>
    <div className="lg-svc">{SERV.map(([ic, t]) => <div key={t}><i className={'fa-solid ' + ic} /><span>{t}</span></div>)}</div>
    <div className="lg-days"><i className="fa-solid fa-calendar-check" /><div><b>Jours de vols : mardi · jeudi · samedi · dimanche</b><br />Déposez vos colis avant 14h</div></div>
    <div className="lg-c"><div><i className="fa-brands fa-whatsapp" /> +237 656 11 50 68</div><div><i className="fa-solid fa-phone" /> +237 658 772 232 · +237 691 448 881</div><div><i className="fa-solid fa-envelope" /> parlementservice@gmail.com</div><div><i className="fa-solid fa-location-dot" /> Douala – Ange Raphaël, avant l'Hôtel le Sélect</div><div><i className="fa-solid fa-location-dot" /> N'Djamena – Moursal, en face de Haroun Kabbadi</div></div></section>
    <section className="lg-r"><div className="lg-card"><h2>{T[0]}</h2><p className="lg-s">{T[1]}</p>
      <div className="lg-tabs">{[['in', 'Connexion'], ['reg', 'Devenir client'], ['trk', 'Suivi']].map(([k, l]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => { setTab(k); setErr(''); }}>{l}</button>)}</div>
      {tab === 'trk' ? <Track /> : <form onSubmit={go} className="lg-f">
        {tab === 'reg' && <><label>Nom ou boutique<input required onChange={set('nom')} /></label><label>Téléphone<input onChange={set('tel')} /></label><label>Ville<input onChange={set('ville')} /></label></>}
        <label>Adresse e-mail<input type="email" required autoComplete="username" onChange={set('email')} /></label><label>Mot de passe<input type="password" required autoComplete="current-password" onChange={set('password')} /></label>
        {err === 'ok' ? <div className="lg-ok">Demande envoyée. Un administrateur validera votre compte.</div> : err && <div className="err">{err}</div>}
        <button className="p lg-b" disabled={busy}>{busy ? 'Veuillez patienter…' : tab === 'in' ? 'Se connecter' : 'Envoyer la demande'}</button></form>}
      <small className="lg-foot">© Parlement Service – Gestion des colis</small></div></section></div>;
}

function Form({ fields, D, init, onSave, onClose, calc }) {
  const [v, setV] = useState(init || {});
  return <div className="m"><form onSubmit={e => { e.preventDefault(); onSave(v); }}>
    {fields.map(([k, l, t, res, opt, when]) => (when && !when(v)) ? null : <label key={k}>{l}
      {t === 'ref' || t === 'sel' ? <select required={!opt} value={v[k] || ''} onChange={e => setV({ ...v, [k]: e.target.value })}><option value="">{opt ? '—' : 'Choisir…'}</option>{(t === 'sel' ? res : (D[res] || []).map(x => [x.id, x.nom])).map(([i, n]) => <option key={i} value={i}>{n}</option>)}</select>
        : <input required={!opt} type={t || 'text'} step="any" value={v[k] ?? ''} onChange={e => setV({ ...v, [k]: e.target.value })} />}</label>)}
    {calc && <p>Frais calculés : <b>{calc(v) || '—'}</b></p>}<div className="bar"><button className="p">Enregistrer</button><button type="button" onClick={onClose}>Annuler</button></div></form></div>;
}

function Resource({ res, D, reload, onInvoice }) {
  const cfg = CFG[res], S = staff(), [edit, setEdit] = useState(null), [hist, setHist] = useState(null), [lbl, setLbl] = useState(null), [err, setErr] = useState('');
  const [fl, setFl] = useState({ q: '', statut: '', ville: '', livreur: '', client: '', p: PRESETS[0], from: '', to: '' });
  const fields = cfg.fields.filter(x => !(role() === 'client' && ['client', 'livreur'].includes(x[0])));
  const rows = (D[res] || []).filter(r => (!fl.q || JSON.stringify(r).toLowerCase().includes(fl.q.toLowerCase())) && (res !== 'parcels' || ((!fl.statut || r.statut === fl.statut) && (!fl.ville || r.ville == fl.ville) && (!fl.livreur || r.livreur == fl.livreur) && (!fl.client || r.client == fl.client) && (!fl.from || r.date >= fl.from) && (!fl.to || r.date <= fl.to))));
  const calc = v => { const c = (D.cities || []).find(x => x.id == v.ville), r = v.categorie === 'cosmetique' ? c?.kg_cosmetique : c?.kg_simple; if (!c || !+v.poids) return ''; const fr = Math.round(v.poids * r), ici = v.paiement === 'destination' ? 0 : v.paiement === 'partiel' ? Math.min(+v.montant_ici || 0, fr) : fr; return `${v.poids} kg × ${money(r)} = ${money(fr)} · payé à l'agence ${money(ici)} · à payer à destination ${money(fr - ici)}`; };
  const run = async fn => { setErr(''); try { await fn(); reload(); } catch (x) { setErr(x.message); } };
  const save = v => run(async () => { await api(`/${res}${v.id ? '/' + v.id : ''}`, v.id ? 'PUT' : 'POST', v); setEdit(null); });
  const lab = k => LAB[k] || cfg.fields.find(x => x[0] === k)?.[1] || k[0].toUpperCase() + k.slice(1);
  const cell = (r, k) => { const d = cfg.fields.find(x => x[0] === k);
    if (k === 'paiement') return <small>{r.paiement === 'destination' ? `À destination · ${MS[r.mode_dest]}` : r.paiement === 'partiel' ? `Partiel : ${money(r.montant_ici)} ici (${MS[r.mode]}) · ${money(r.montant_dest)} dest. (${MS[r.mode_dest]})` : `Payé ici · ${MS[r.mode || 'especes']}`}{+r.montant_dest > 0 && (r.dest_paye ? ' · encaissé' : ' · à encaisser')}</small>;
    if (k === 'poids') return r.poids + ' kg'; if (k === 'categorie') return r.categorie === 'cosmetique' ? 'Cosmétique' : 'Simple'; if (k === 'trajet') return 'Douala → ' + r.nom; if (k === 'kg_simple' || k === 'kg_cosmetique') return +r[k] ? '1 kg = ' + money(r[k]) : '—';
    if (k === 'statut') return S || role() === 'livreur' ? <select value={r.statut} onChange={e => run(() => api(`/parcels/${r.id}/statut`, 'PATCH', { statut: e.target.value }))}>{STATUTS.map(s => <option key={s}>{s}</option>)}</select> : r.statut;
    if (k === 'etat' && ETAT[res] && S) return <select value={r.etat} onChange={e => run(() => api(`/${res}/${r.id}`, 'PUT', { etat: e.target.value }))}>{ETAT[res].map(s => <option key={s}>{s}</option>)}</select>;
    if (k === 'docs') return <small>{Object.values(r.docs || {}).join(' · ')}</small>;
    if (k === 'role') return ROLES.find(x => x[0] === r.role)?.[1];
    if (k === 'zone') return nameOf(D, 'zones', r.zone);
    if (k === 'clientId') return r.clientId ? nameOf(D, 'clients', r.clientId) : '-';
    if (k === 'driverId') return r.driverId ? nameOf(D, 'drivers', r.driverId) : '-';
    if (d?.[2] === 'ref') return nameOf(D, d[3], r[k]);
    return MONEY.includes(k) ? money(r[k]) : r[k]; };
  const exp = () => { const L = [['code', 'date', 'destinataire', 'tel', 'ville', 'poids', 'frais', 'statut'], ...rows.map(r => [r.code, r.date, r.dest, r.tel, nameOf(D, 'cities', r.ville), r.poids, r.frais, r.statut])];
    const a = document.createElement('a'); a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(L.map(x => x.join(';')).join('\n')); a.download = 'colis.csv'; a.click(); };
  const canAdd = res !== 'newclients' && (S || ['parcels', 'claims', 'modifs'].includes(res)), canEdit = S && !['modifs', 'newclients'].includes(res);
  const sel = (k, list, l) => <select value={fl[k]} onChange={e => setFl({ ...fl, [k]: e.target.value })}><option value="">{l}</option>{(D[list] || []).map(x => <option key={x.id} value={x.id}>{x.nom}</option>)}</select>;
  return <>
    <div className="bar">{canAdd && <button className="p" onClick={() => setEdit(res === 'parcels' ? { paiement: 'paye_ici', mode: 'especes', mode_dest: 'especes' } : { date: f(new Date()) })}>+ Ajouter</button>}<input placeholder="Rechercher…" value={fl.q} onChange={e => setFl({ ...fl, q: e.target.value })} />
      {res === 'parcels' && <><Range v={fl} set={setFl} /><select value={fl.statut} onChange={e => setFl({ ...fl, statut: e.target.value })}><option value="">Tous statuts</option>{STATUTS.map(s => <option key={s}>{s}</option>)}</select>
        {S && <>{sel('client', 'clients', 'Tous clients')}{sel('livreur', 'drivers', 'Tous livreurs')}{sel('ville', 'cities', 'Toutes villes')}</>}<button onClick={exp}>Exporter CSV</button></>}</div>
    {err && <p className="err">{err}</p>}
    <div className="card"><table><thead><tr>{cfg.cols.map(c => <th key={c}>{lab(c)}</th>)}<th /></tr></thead><tbody>
      {rows.map(r => <tr key={r.id}>{cfg.cols.map(c => <td key={c}>{cell(r, c)}</td>)}<td>
        {res === 'parcels' && <><button onClick={() => setHist(r)}>Historique</button> <button onClick={() => setLbl(r)}>Étiquette</button>{S && <> <button onClick={() => onInvoice(r)}>Facture</button></>}{S && +r.montant_dest > 0 && !r.dest_paye && <> <button className="p" onClick={() => run(() => api(`/parcels/${r.id}/dest-paye`, 'PATCH', { paye: true }))}>Encaissé dest.</button></>} </>}
        {res === 'modifs' && S && r.etat === 'En attente' && <><button onClick={() => run(() => api(`/modifs/${r.id}/decision`, 'POST', { decision: 'Approuvée' }))}>Approuver</button> <button onClick={() => run(() => api(`/modifs/${r.id}/decision`, 'POST', { decision: 'Refusée' }))}>Refuser</button></>}
        {res === 'newclients' && r.etat === 'En attente' && <button className="p" onClick={() => run(() => api(`/newclients/${r.id}/approve`, 'POST'))}>Valider</button>}
        {canEdit && <> <button onClick={() => setEdit(r)}>Modifier</button></>}
        {S && <> <button onClick={() => confirm('Supprimer ?') && run(() => api(`/${res}/${r.id}`, 'DELETE'))}>Supprimer</button></>}</td></tr>)}
      {!rows.length && <tr><td colSpan={cfg.cols.length + 1}>Aucune entrée.</td></tr>}</tbody></table></div>
    {edit && <Form fields={fields} D={D} init={edit} onSave={save} onClose={() => setEdit(null)} calc={res === 'parcels' ? calc : undefined} />}
    {lbl && <Label p={lbl} D={D} onClose={() => setLbl(null)} />}{hist && <div className="m" onClick={() => setHist(null)}><div className="card" style={{ minWidth: 300 }}><b>{hist.code}</b><ul className="tl">{(hist.historique || []).map((h, i) => <li key={i}>{h.statut} – {new Date(h.date).toLocaleString('fr-FR')}</li>)}</ul></div></div>}</>;
}

const short = n => n >= 1e6 ? (n / 1e6).toFixed(1) + ' M' : n >= 1e3 ? Math.round(n / 1e3) + ' k' : Math.round(n);
const Kpi = ({ icon, label, value, sub, tone = 'brand' }) => <div className="kpi" style={{ '--c': TONES[tone] }}><span className="kpi-i"><i className={'fa-solid ' + icon} /></span><div><small>{label}</small><b>{value}</b>{sub && <em>{sub}</em>}</div></div>;
const Sec = ({ icon, title, right, children }) => <section className="card sec"><div className="bar" style={{ justifyContent: 'space-between', marginBottom: 8 }}><h3 style={{ margin: 0 }}><i className={'fa-solid ' + icon} /> {title}</h3>{right}</div>{children}</section>;
function Donut({ data, center, unit = 'colis', size = 170 }) {
  const T = data.reduce((a, d) => a + d.v, 0) || 1, r = 56, C = 2 * Math.PI * r; let off = 0;
  return <div className="donut"><svg width={size} height={size} viewBox="0 0 160 160"><circle cx="80" cy="80" r={r} fill="none" stroke="#eef0f4" strokeWidth="22" />
    {data.filter(d => d.v > 0).map(d => { const len = d.v / T * C, el = <circle key={d.l} cx="80" cy="80" r={r} fill="none" stroke={d.c} strokeWidth="22" strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-off} transform="rotate(-90 80 80)" />; off += len; return el; })}
    <text x="80" y="78" textAnchor="middle" className="dn">{center}</text><text x="80" y="96" textAnchor="middle" className="ds">{unit}</text></svg>
    <ul>{data.map(d => <li key={d.l}><i style={{ background: d.c }} />{d.l}<b>{d.fmt || d.v}</b></li>)}</ul></div>;
}
function Bars({ data, series, h = 190, raw }) {
  const W = 640, P = 34, max = Math.max(1, ...data.flatMap(d => series.map(x => d[x.key] || 0))), bw = (W - P * 2) / Math.max(1, data.length);
  const lab = k => raw ? k.slice(0, 10) : k.length > 7 ? k.slice(8) + '/' + k.slice(5, 7) : k.slice(5) + '/' + k.slice(2, 4);
  return <div className="chart"><svg viewBox={`0 0 ${W} ${h + 30}`} width="100%">
    {[0, .5, 1].map(t => <g key={t}><line x1={P} x2={W - P} y1={h - t * (h - 12)} y2={h - t * (h - 12)} stroke="#eceef3" /><text x={P - 5} y={h - t * (h - 12) + 3} textAnchor="end" className="ax">{short(max * t)}</text></g>)}
    {data.map((d, i) => series.map((x, j) => { const v = d[x.key] || 0, bh = v / max * (h - 12), w = (bw - 6) / series.length; return <rect key={i + x.key} x={P + i * bw + 3 + j * w} y={h - bh} width={Math.max(2, w - 2)} height={bh} rx="2" fill={x.color}><title>{`${d.k} – ${x.label} : ${money(v)}`}</title></rect>; }))}
    {data.map((d, i) => (data.length <= 14 || i % Math.ceil(data.length / 12) === 0) && <text key={d.k} x={P + i * bw + bw / 2} y={h + 16} textAnchor="middle" className="ax">{lab(d.k)}</text>)}</svg>
    <div className="leg">{series.map(x => <span key={x.key}><i style={{ background: x.color }} />{x.label}</span>)}</div></div>;
}
const statData = p => STATUTS.map(t => ({ l: t, v: p[t] || 0, c: SCOL[t] }));

const DT = ({ title, g }) => <Sec icon="file-invoice-dollar" title={title}><table><thead><tr><th>Statut</th><th>Factures</th><th>Colis</th><th>Montant</th><th>Total TTC</th></tr></thead>
  <tbody>{['Non payé', 'Payé'].map(k => <tr key={k}><td>{k}</td><td>{g[k].n}</td><td>{g[k].colis}</td><td>{money(g[k].montant)}</td><td>{money(g[k].total)}</td></tr>)}</tbody></table></Sec>;
function Stats({ D }) {
  const [fl, setFl] = useState({ p: PRESETS[0], from: '', to: '', client: '', livreur: '', ville: '', zone: '' }), [s, setS] = useState(null), [dim, setDim] = useState(''), [cmp, setCmp] = useState([]);
  const qs = () => new URLSearchParams(Object.fromEntries(Object.entries(fl).filter(([k, v]) => v && k !== 'p'))).toString();
  useEffect(() => { api('/stats?' + qs()).then(setS); dim ? api(`/stats/compare?dim=${dim}&` + qs()).then(setCmp) : setCmp([]); }, [fl, dim]);
  const sel = (k, list, l) => <select value={fl[k]} onChange={e => setFl({ ...fl, [k]: e.target.value })}><option value="">{l}</option>{(D[list] || []).map(x => <option key={x.id} value={x.id}>{x.nom}</option>)}</select>;
  if (!s) return <p>Chargement…</p>;
  return <><div className="card"><div className="bar" style={{ margin: 0 }}><Range v={fl} set={setFl} />{sel('client', 'clients', 'Tous clients')}{sel('livreur', 'drivers', 'Tous livreurs')}{sel('ville', 'cities', 'Toutes villes')}{sel('zone', 'zones', 'Toutes zones')}
    <select value={dim} onChange={e => setDim(e.target.value)}><option value="">Comparer par…</option><option value="client">Clients</option><option value="livreur">Livreurs</option><option value="zone">Zones</option><option value="ville">Villes</option></select></div></div>
    <div className="grid"><Kpi icon="fa-box" label="Total colis" value={s.total} tone="blue" /><Kpi icon="fa-circle-check" label="Colis livrés" value={s.parStatut['Livré']} tone="green" /><Kpi icon="fa-coins" label="Chiffre d'affaires (livré)" value={money(s.ca)} />
      <Kpi icon="fa-weight-hanging" label="Poids livré" value={s.poids + ' kg'} tone="violet" /><Kpi icon="fa-receipt" label="Dépenses" value={money(s.depenses)} tone="amber" /><Kpi icon="fa-chart-line" label="Bénéfice" value={money(s.benefice)} tone={s.benefice >= 0 ? 'green' : 'red'} /></div>
    <div className="cols"><Sec icon="chart-pie" title="Répartition des colis par statut"><Donut data={statData(s.parStatut)} center={s.total} /></Sec>
      <Sec icon="list-check" title="Détail par statut">{STATUTS.map(t => <div className="row" key={t}><span style={{ width: 150 }}>{t}</span><progress max={s.total || 1} value={s.parStatut[t]} style={{ accentColor: SCOL[t], flex: 1 }} /><b>{s.parStatut[t]}</b></div>)}</Sec></div>
    {s.docs && <DT title="Factures" g={s.docs.facture} />}
    {dim && <Sec icon="scale-balanced" title="Comparaison"><Bars raw data={cmp.map(r => ({ k: r.nom, ca: r.ca }))} series={[{ key: 'ca', label: "CA livré", color: '#e8761c' }]} />
      <table><thead><tr><th>Nom</th><th>Colis</th><th>Livrés</th><th>Refusés</th><th>Retournés</th><th>Poids livré</th><th>CA livré</th></tr></thead>
        <tbody>{cmp.map(r => <tr key={r.id}><td>{r.nom}</td><td>{r.total}</td><td>{r.livre}</td><td>{r.refuse}</td><td>{r.retourne}</td><td>{r.poids} kg</td><td>{money(r.ca)}</td></tr>)}</tbody></table></Sec>}</>;
}

function Invoice({ view, D, dim, res, S }) {
  const d = view.doc, P = view.parcels, ratio = d.montant ? d.total / d.montant : 1, tva = d.total - d.montant, cl = dim === 'client' ? (D.clients || []).find(x => x.id == d.partie) : null;
  const sm = (f) => P.reduce((a, p) => a + f(p), 0), R = n => Math.round(n * ratio);
  const ici = R(sm(p => +p.montant_ici || 0)), destDone = R(sm(p => p.dest_paye ? +p.montant_dest || 0 : 0)), reste = R(sm(p => !p.dest_paye ? +p.montant_dest || 0 : 0));
  const mod = p => p.paiement === 'destination' ? 'À payer à destination' : p.paiement === 'partiel' ? 'Partiel' : "Payé à l'agence";
  return <div className="inv">
    <div className="inv-h"><div className="inv-b"><Logo size={58} /><div><h2>{S.nom || 'Parlement Service'}</h2><small>{S.adresse}<br />{[S.tel1, S.tel2, S.email].filter(Boolean).join(' · ')}</small></div></div>
      <div className="inv-t"><h1>FACTURE</h1><div>N° <b>{d.ref}</b></div><div>Date : {d.date}</div></div></div>
    <div className={'stamp ' + (reste === 0 ? 'ok' : 'due')}>{reste === 0 ? 'PAYÉE' : 'SOLDE À PAYER'}</div>
    <div className="inv-c"><small>FACTURÉ À</small><b>{nameOf(D, res, d.partie)}</b>{cl && <span>{[cl.tel, cl.ville, cl.email].filter(Boolean).join(' · ')}</span>}</div>
    <table><thead><tr><th>N°</th><th>Colis</th><th>Destinataire / Destination</th><th>Poids</th><th>Frais</th><th>Modalité de paiement</th><th>Payé à l'agence</th><th>À payer à destination</th></tr></thead>
      <tbody>{P.map((p, i) => <tr key={p.id}><td>{i + 1}</td><td>{p.code}</td><td>{p.dest}<br /><small>{nameOf(D, 'cities', p.ville)}</small></td><td>{p.poids} kg</td><td>{money(p.frais)}</td><td>{mod(p)}</td>
        <td>{+p.montant_ici ? <>{money(p.montant_ici)}<br /><small>{MS[p.mode]}</small></> : '—'}</td><td>{+p.montant_dest ? <>{money(p.montant_dest)}<br /><small>{MS[p.mode_dest]}{p.dest_paye ? ' · encaissé' : ''}</small></> : '—'}</td></tr>)}</tbody></table>
    <div className="inv-s"><div><span>Nombre de colis</span><b>{d.colis}</b></div><div><span>Poids total</span><b>{d.poids} kg</b></div><div><span>Sous-total</span><b>{money(d.montant)}</b></div><div><span>TVA ({d.tva || 0} %)</span><b>{money(tva)}</b></div>
      <div><span>Total TTC</span><b>{money(d.total)}</b></div><div><span>Payé à l'agence</span><b>− {money(ici)}</b></div>{destDone > 0 && <div><span>Payé à la destination</span><b>− {money(destDone)}</b></div>}
      <div className="inv-g"><span>RESTE À PAYER (destination)</span><b>{money(reste)}</b></div></div>
    <div className="inv-f"><div><b>Conditions</b><br />Modes de paiement acceptés : espèces, Orange Money (OM), MTN MoMo (MOMO).<br />Merci de votre confiance. Parlement Service – Là où vos échanges internationaux font loi. Dépôt des colis avant 14h.</div><div className="inv-sig">Cachet et signature</div></div>
    <div className="inv-bar">{S.nom || 'Parlement Service'} – {S.adresse} – {S.tel1}</div></div>;
}
function DocPage({ type, D, reload, openId, clear }) {
  const [, label, dim] = DOCS.find(d => d[0] === type), res = DIMRES[dim];
  const [docs, setDocs] = useState([]), [nw, setNw] = useState(false), [partie, setPartie] = useState(''), [el, setEl] = useState([]), [chk, setChk] = useState([]), [view, setView] = useState(null), [err, setErr] = useState(''), [S, setS] = useState({});
  const load = useCallback(() => api('/documents?type=' + type).then(setDocs), [type]);
  useEffect(() => { load(); api('/settings').then(setS).catch(() => { }); }, [load]);
  useEffect(() => { if (openId) api('/documents/' + openId).then(setView); }, [openId]);
  useEffect(() => { partie ? api(`/documents/eligible?type=${type}&partie=${partie}`).then(r => { setEl(r); setChk(r.map(p => p.id)); }) : (setEl([]), setChk([])); }, [partie, type]);
  const run = async fn => { setErr(''); try { await fn(); load(); reload(); } catch (x) { setErr(x.message); } };
  const picked = el.filter(p => chk.includes(p.id));
  return <><div className="bar"><button className="p" onClick={() => setNw(true)}><i className="fa-solid fa-plus" /> Nouvelle facture</button></div>{err && <p className="err">{err}</p>}
    <div className="card"><table><thead><tr><th>Référence</th><th>Client</th><th>Date</th><th>Colis</th><th>Poids</th><th>Montant</th><th>Total TTC</th><th>Statut</th><th /></tr></thead><tbody>
      {docs.map(d => <tr key={d.id}><td><b>{d.ref}</b></td><td>{nameOf(D, res, d.partie)}</td><td>{d.date}</td><td>{d.colis}</td><td>{d.poids} kg</td><td>{money(d.montant)}</td><td>{money(d.total)}</td>
        <td><select value={d.statut} onChange={e => run(() => api(`/documents/${d.id}/statut`, 'PATCH', { statut: e.target.value }))}><option>Non payé</option><option>Payé</option></select></td>
        <td><button onClick={async () => setView(await api('/documents/' + d.id))}>Voir / Imprimer</button> <button onClick={() => confirm('Supprimer cette facture ? Les colis redeviennent facturables.') && run(() => api('/documents/' + d.id, 'DELETE'))}>Supprimer</button></td></tr>)}
      {!docs.length && <tr><td colSpan="9">Aucune facture. Cliquez sur « Nouvelle facture » ou sur « Facture » dans la liste des colis.</td></tr>}</tbody></table></div>
    {nw && <div className="m"><div style={{ background: '#fff', padding: 20, borderRadius: 14, width: 'min(520px,100%)', display: 'grid', gap: 10, maxHeight: '92vh', overflow: 'auto' }}><b>Nouvelle facture</b>
      <select value={partie} onChange={e => setPartie(e.target.value)}><option value="">Choisir le client…</option>{(D[res] || []).map(x => <option key={x.id} value={x.id}>{x.nom}</option>)}</select>
      {partie && (el.length ? <><div style={{ maxHeight: 220, overflow: 'auto', border: '1px solid #e6e8ee', borderRadius: 8, padding: 8 }}>{el.map(p => <label key={p.id} className="chk"><input type="checkbox" checked={chk.includes(p.id)} onChange={e => setChk(e.target.checked ? [...chk, p.id] : chk.filter(i => i !== p.id))} />{p.code} · {p.dest} · {p.poids} kg · {money(p.frais)}</label>)}</div>
        <p style={{ margin: 0 }}><b>{picked.length}</b> colis · {picked.reduce((a, p) => a + (+p.poids || 0), 0)} kg · <b>{money(picked.reduce((a, p) => a + (+p.frais || 0), 0))}</b></p></> : <p>Tous les colis de ce client sont déjà facturés.</p>)}
      <div className="bar"><button className="p" disabled={!picked.length} onClick={() => run(async () => { const doc = await api('/documents', 'POST', { type, partie, ids: chk }); setNw(false); setPartie(''); setView(await api('/documents/' + doc.id)); })}>Générer la facture</button><button onClick={() => { setNw(false); setPartie(''); }}>Annuler</button></div></div></div>}
    {view && <div className="m"><div className="print" style={{ background: '#fff', width: '100%', maxWidth: 900, maxHeight: '92vh', overflow: 'auto', borderRadius: 12 }}><Invoice view={view} D={D} dim={dim} res={res} S={S} />
      <div className="bar noprint" style={{ padding: 14 }}><button className="p" onClick={() => print()}><i className="fa-solid fa-print" /> Imprimer / PDF</button><button onClick={() => { setView(null); clear && clear(); }}>Fermer</button></div></div></div>}</>;
}

const FP = [...PRESETS.slice(1), 'Tout'];
function Finance({ D }) {
  const [p, setP] = useState(FP[2]), [F, setF] = useState(null), [form, setForm] = useState(false), [err, setErr] = useState('');
  const q = () => p === 'Tout' ? 'all=1' : (([a, b]) => `from=${a}&to=${b}`)(rng(p));
  const load = () => api('/finance?' + q()).then(setF).catch(x => setErr(x.message));
  useEffect(() => { load(); }, [p]);
  if (!F) return <p>{err || 'Chargement…'}</p>;
  const G = F.groupes, sub = g => `${money(g.montant)} · ${g.poids} kg`, run = async fn => { setErr(''); try { await fn(); load(); } catch (x) { setErr(x.message); } };
  const modes = [['especes', 'Espèces', '#16a34a'], ['om', 'Orange Money', '#ea580c'], ['momo', 'MTN MoMo', '#d97706']].map(([k, l, c]) => ({ l, c, v: F.modes[k] || 0, fmt: money(F.modes[k] || 0) }));
  const cats = ['#2563eb', '#7c3aed', '#d97706', '#0e7490', '#475569', '#16a34a'];
  return <><div className="bar noprint"><select value={p} onChange={e => setP(e.target.value)}>{FP.map(x => <option key={x}>{x}</option>)}</select><span style={{ color: '#6b7280' }}>Du {F.from} au {F.to}</span>
    <button className="p" onClick={() => setForm(true)}><i className="fa-solid fa-plus" /> Ajouter une dépense</button><button onClick={() => print()}><i className="fa-solid fa-print" /> Imprimer</button></div>{err && <p className="err">{err}</p>}
    <div className="print"><div className="grid">
      <Kpi icon="fa-paper-plane" label="Colis expédiés (livrés + en cours)" value={G.expedies.colis} sub={sub(G.expedies)} tone="blue" /><Kpi icon="fa-circle-check" label="Livrés" value={G.livres.colis} sub={sub(G.livres)} tone="green" />
      <Kpi icon="fa-truck-fast" label="En cours d'envoi" value={G.cours.colis} sub={sub(G.cours)} tone="violet" /><Kpi icon="fa-box-open" label="Non envoyés (restants)" value={G.non.colis} sub={sub(G.non)} tone="amber" /></div>
    <div className="grid"><Kpi icon="fa-file-invoice-dollar" label="Chiffre d'affaires" value={money(F.ca)} /><Kpi icon="fa-hand-holding-dollar" label="Encaissé" value={money(F.encaisse)} tone="green" />
      <Kpi icon="fa-hourglass-half" label="Reste à encaisser" value={money(F.reste)} tone="amber" /><Kpi icon="fa-receipt" label="Dépenses" value={money(F.depenses)} tone="slate" />
      <Kpi icon="fa-scale-balanced" label="Résultat net (encaissé − dépenses)" value={money(F.net)} tone={F.net >= 0 ? 'green' : 'red'} /><Kpi icon="fa-chart-line" label="Résultat prévisionnel (CA − dépenses)" value={money(F.previsionnel)} tone="blue" /></div>
    <Sec icon="chart-column" title="Évolution : chiffre d'affaires, encaissements et dépenses"><Bars data={F.series} series={[{ key: 'ca', label: "Chiffre d'affaires", color: '#e8761c' }, { key: 'enc', label: 'Encaissé', color: '#16a34a' }, { key: 'dep', label: 'Dépenses', color: '#475569' }]} /></Sec>
    <div className="cols"><Sec icon="table" title="Récapitulatif des colis"><table><thead><tr><th>Situation</th><th>Colis</th><th>Poids</th><th>Montant</th></tr></thead><tbody>
      {[['Non envoyés (restants)', G.non], ["En cours d'envoi", G.cours], ['Livrés', G.livres], ['Total expédiés', G.expedies], ['Refusés / retournés (exclus)', G.ko]].map(([l, g]) => <tr key={l}><td>{l}</td><td>{g.colis}</td><td>{g.poids} kg</td><td>{money(g.montant)}</td></tr>)}
      <tr><td><b>Total hors refus</b></td><td><b>{G.total.colis}</b></td><td><b>{G.total.poids} kg</b></td><td><b>{money(G.total.montant)}</b></td></tr></tbody></table></Sec>
      <Sec icon="mobile-screen" title="Encaissements par mode"><Donut data={modes} center={short(F.encaisse)} unit="FCFA" /></Sec></div></div>
    <Sec icon="location-dot" title={`À encaisser à la destination (${F.aEncaisserDest.length})`}><table><thead><tr><th>Colis</th><th>Client</th><th>Ville</th><th>Statut</th><th>Mode prévu</th><th>Montant</th><th /></tr></thead><tbody>
      {F.aEncaisserDest.map(x => <tr key={x.id}><td>{x.code}</td><td>{x.client}</td><td>{x.ville}</td><td>{x.statut}</td><td>{MS[x.mode]}</td><td><b>{money(x.montant)}</b></td><td><button className="p" onClick={() => run(() => api(`/parcels/${x.id}/dest-paye`, 'PATCH', { paye: true }))}>Marquer encaissé</button></td></tr>)}
      {!F.aEncaisserDest.length && <tr><td colSpan="7">Rien à encaisser à destination.</td></tr>}</tbody></table></Sec>
    <div className="cols"><Sec icon="users" title="Situation par client"><table><thead><tr><th>Client</th><th>Colis</th><th>Total</th><th>Encaissé</th><th>Reste dû</th></tr></thead><tbody>
      {F.clients.map(c => <tr key={c.id}><td>{c.nom}</td><td>{c.colis}</td><td>{money(c.total)}</td><td>{money(c.encaisse)}</td><td className={c.reste > 0 ? 'neg' : 'pos'}><b>{money(c.reste)}</b></td></tr>)}{!F.clients.length && <tr><td colSpan="5">Aucune donnée.</td></tr>}</tbody></table></Sec>
      <Sec icon="city" title="Par destination"><table><thead><tr><th>Ville</th><th>Colis</th><th>Poids</th><th>Montant</th></tr></thead><tbody>{F.villes.map(v => <tr key={v.nom}><td>{v.nom}</td><td>{v.colis}</td><td>{v.poids} kg</td><td>{money(v.montant)}</td></tr>)}{!F.villes.length && <tr><td colSpan="4">Aucune donnée.</td></tr>}</tbody></table></Sec></div>
    <Sec icon="receipt" title={`Dépenses (${money(F.depenses)})`} right={<span>{Object.entries(F.parCategorie).map(([c, v], i) => <span className="chip" key={c} style={{ borderColor: cats[i % 6] }}>{c} : {money(v)}</span>)}</span>}>
      <table><thead><tr><th>Date</th><th>Titre</th><th>Catégorie</th><th>Description</th><th>Montant</th><th className="noprint" /></tr></thead><tbody>
        {F.depensesListe.map(e => <tr key={e.id}><td>{e.date}</td><td>{e.titre}</td><td>{e.categorie || 'Autre'}</td><td>{e.desc}</td><td><b>{money(e.montant)}</b></td><td className="noprint"><button onClick={() => confirm('Supprimer cette dépense ?') && run(() => api('/expenses/' + e.id, 'DELETE'))}>Supprimer</button></td></tr>)}
        {!F.depensesListe.length && <tr><td colSpan="6">Aucune dépense sur la période.</td></tr>}</tbody></table></Sec>
    {form && <Form fields={[['titre', 'Titre'], ['categorie', 'Catégorie', 'sel', ['Transport', 'Emballage', 'Salaires', 'Loyer', 'Communication', 'Autre'].map(x => [x, x])], ['montant', 'Montant (FCFA)', 'number'], ['date', 'Date', 'date'], ['desc', 'Description', 'text', 0, 1]]} D={D} init={{ date: f(new Date()), categorie: 'Transport' }}
      onSave={v => run(async () => { await api('/expenses', 'POST', v); setForm(false); })} onClose={() => setForm(false)} />}</>;
}

function Settings() {
  const [s, setS] = useState(null), [ok, setOk] = useState('');
  useEffect(() => { api('/settings').then(setS); }, []);
  if (!s) return null;
  const T = [['nom', "Nom de l'entreprise"], ['adresse', 'Adresse'], ['tel1', 'Téléphone'], ['tel2', 'Téléphone 2'], ['email', 'E-mail'], ['website', 'Site web'], ['tva', 'TVA sur factures (%)'], ['lot_kg', 'Poids d\'un tas à emballer (kg)'], ['heure_cloture', 'Heure de clôture journalière (HH:MM)'], ['sms_tpl', 'Modèle SMS ({code}, {statut})'], ['mail_tpl', "Modèle e-mail ({code}, {statut})"]];
  return <form className="card" style={{ display: 'grid', gap: 8, maxWidth: 640 }} onSubmit={async e => { e.preventDefault(); await api('/settings', 'PUT', s); setOk('Paramètres enregistrés.'); }}>
    {T.map(([k, l]) => <label key={k}>{l}<input value={s[k] || ''} onChange={e => setS({ ...s, [k]: e.target.value })} /></label>)}
    <label><span><input type="checkbox" checked={!!s.sms_on} onChange={e => setS({ ...s, sms_on: e.target.checked })} /> Envoyer un SMS à chaque changement de statut</span></label>
    <label><span><input type="checkbox" checked={!!s.mail_on} onChange={e => setS({ ...s, mail_on: e.target.checked })} /> Envoyer un e-mail au client à chaque changement de statut</span></label>
    <button className="p">Enregistrer</button>{ok && <span>{ok}</span>}</form>;
}
function Notifs() {
  const [L, setL] = useState([]); useEffect(() => { api('/notifications').then(setL); }, []);
  return <div className="card"><table><thead><tr><th>Date</th><th>Canal</th><th>Destinataire</th><th>Message</th></tr></thead><tbody>{L.map(n => <tr key={n.id}><td>{new Date(n.date).toLocaleString('fr-FR')}</td><td>{n.canal}</td><td>{n.to}</td><td>{n.msg}</td></tr>)}{!L.length && <tr><td colSpan="4">Aucune notification (activez-les dans Paramètres).</td></tr>}</tbody></table></div>;
}

const accent = () => (getComputedStyle(document.documentElement).getPropertyValue('--ac') || getComputedStyle(document.documentElement).getPropertyValue('--red') || '#d9141c').trim();
function Stock({ D }) {
  const [tab, setTab] = useState('stock'), [S, setS] = useState(null), [moves, setMoves] = useState([]), [form, setForm] = useState(null), [err, setErr] = useState(''), [mf, setMf] = useState({ produit: '', type: '' });
  const load = () => { api('/stock').then(setS); api('/stock/moves').then(setMoves); };
  useEffect(() => { load(); }, []);
  const run = async fn => { setErr(''); try { await fn(); load(); } catch (x) { setErr(x.message); } };
  if (!S) return <p>Chargement…</p>;
  const T = S.totaux, prods = S.produits, opts = prods.map(p => [p.id, `${p.produit} (restant : ${p.restant})`]), nm = id => (prods.find(p => p.id == id) || {}).produit;
  const pf = [['produit', 'Produit / article'], ['client', 'Client propriétaire', 'ref', 'clients', 1], ['prix_achat', "Prix d'achat unitaire (FCFA)", 'number', 0, 1], ['prix_vente', 'Prix de vente unitaire (FCFA)', 'number'], ['seuil', "Seuil d'alerte (quantité)", 'number', 0, 1], ['quantite_initiale', 'Quantité initiale en stock', 'number', 0, 1, v => !v.id]];
  const mfld = t => [['produit', 'Produit', 'sel', opts], ['quantite', 'Quantité', 'number'], ['prix_unitaire', t === 'sortie' ? 'Prix de vente unitaire (vide = prix du produit)' : "Prix d'achat unitaire (facultatif)", 'number', 0, 1], ['date', 'Date', 'date'], ['note', 'Motif / remarque', 'text', 0, 1]];
  const move = (type, p) => setForm({ kind: type, init: { produit: p?.id || '', date: f(new Date()) } });
  const shown = moves.filter(m => (!mf.produit || m.produit == mf.produit) && (!mf.type || m.type === mf.type));
  return <>
    <div className="tabs" style={{ marginBottom: 14, width: 'fit-content' }}>{[['stock', 'Stock'], ['moves', 'Mouvements'], ['report', 'Rapport']].map(([k, l]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</div>
    {err && <p className="err">{err}</p>}
    {tab === 'stock' && <>
      <div className="bar"><button className="p" onClick={() => setForm({ kind: 'prod', init: {} })}><i className="fa-solid fa-plus" /> Produit</button><button onClick={() => move('entree')}><i className="fa-solid fa-arrow-down" /> Entrée de stock</button><button onClick={() => move('sortie')}><i className="fa-solid fa-arrow-up" /> Sortie / vente</button></div>
      <div className="grid"><Kpi icon="fa-arrow-down" label="Stock entrant (total)" value={T.entrees} tone="green" /><Kpi icon="fa-arrow-up" label="Stock sortant (total)" value={T.sorties} tone="amber" /><Kpi icon="fa-boxes-stacked" label="Stock restant" value={T.restant} tone="blue" />
        <Kpi icon="fa-coins" label="Prix des stocks vendus" value={money(T.ca)} /><Kpi icon="fa-chart-line" label="Marge sur ventes" value={money(T.marge)} tone={T.marge >= 0 ? 'green' : 'red'} /><Kpi icon="fa-warehouse" label="Valeur du stock restant" value={money(T.valeur_restante)} tone="violet" /></div>
      <div className="card"><table><thead><tr><th>Produit</th><th>Client</th><th>Entrées</th><th>Sorties</th><th>Restant</th><th>Prix de vente</th><th>Ventes</th><th>Marge</th><th>Valeur restante</th><th /></tr></thead><tbody>
        {prods.map(p => <tr key={p.id}><td><b>{p.produit}</b></td><td>{p.client ? nameOf(D, 'clients', p.client) : '—'}</td><td>{p.entrees}</td><td>{p.sorties}</td><td><b className={p.alerte ? 'neg' : ''}>{p.restant}</b>{p.alerte && <small className="neg"> · stock bas</small>}</td><td>{money(p.prix_vente)}</td><td>{money(p.ca)}</td><td>{money(p.marge)}</td><td>{money(p.valeur_restante)}</td>
          <td><button onClick={() => move('entree', p)}>+ Entrée</button> <button onClick={() => move('sortie', p)}>− Sortie</button> <button onClick={() => setForm({ kind: 'prod', init: p })}>Modifier</button> <button onClick={() => confirm('Supprimer ce produit et ses mouvements ?') && run(() => api('/stock/' + p.id, 'DELETE'))}>Supprimer</button></td></tr>)}
        {!prods.length && <tr><td colSpan="10">Aucun produit. Cliquez sur « Produit » pour commencer.</td></tr>}</tbody></table></div></>}
    {tab === 'moves' && <>
      <div className="bar"><select value={mf.produit} onChange={e => setMf({ ...mf, produit: e.target.value })}><option value="">Tous les produits</option>{prods.map(p => <option key={p.id} value={p.id}>{p.produit}</option>)}</select>
        <select value={mf.type} onChange={e => setMf({ ...mf, type: e.target.value })}><option value="">Entrées et sorties</option><option value="entree">Entrées</option><option value="sortie">Sorties</option></select></div>
      <div className="card"><table><thead><tr><th>Date</th><th>Produit</th><th>Mouvement</th><th>Quantité</th><th>Prix unitaire</th><th>Montant</th><th>Motif</th><th /></tr></thead><tbody>
        {shown.map(m => <tr key={m.id}><td>{m.date}</td><td>{m.nom}</td><td><span className={'tag ' + (m.type === 'entree' ? 'pos' : 'neg')}>{m.type === 'entree' ? 'Entrée' : 'Sortie'}</span></td><td>{m.quantite}</td><td>{money(m.prix_unitaire)}</td><td>{money(m.quantite * m.prix_unitaire)}</td><td>{m.note}</td>
          <td><button onClick={() => confirm('Supprimer ce mouvement ?') && run(() => api('/stock/moves/' + m.id, 'DELETE'))}>Supprimer</button></td></tr>)}
        {!shown.length && <tr><td colSpan="8">Aucun mouvement.</td></tr>}</tbody></table></div></>}
    {tab === 'report' && <StockReport />}
    {form && <Form fields={form.kind === 'prod' ? pf : mfld(form.kind)} D={D} init={form.init} onClose={() => setForm(null)}
      onSave={v => run(async () => { form.kind === 'prod' ? await api('/stock' + (v.id ? '/' + v.id : ''), v.id ? 'PUT' : 'POST', v) : await api('/stock/moves', 'POST', { ...v, type: form.kind }); setForm(null); })} />}</>;
}
function StockReport() {
  const [mode, setMode] = useState('day'), [date, setDate] = useState(f(new Date())), [rg, setRg] = useState({ from: f(new Date()), to: f(new Date()) }), [r, setR] = useState(null);
  useEffect(() => { api('/stock/report?' + (mode === 'custom' ? `from=${rg.from}&to=${rg.to}` : `period=${mode}&date=${date}`)).then(setR); }, [mode, date, rg.from, rg.to]);
  const TT = { day: 'journalier', week: 'hebdomadaire', month: 'mensuel', custom: 'sur la période' };
  return <><div className="card noprint"><div className="bar" style={{ margin: 0 }}><div className="tabs">{[['day', 'Jour'], ['week', 'Semaine'], ['month', 'Mois'], ['custom', 'Période']].map(([k, l]) => <button key={k} className={mode === k ? 'on' : ''} onClick={() => setMode(k)}>{l}</button>)}</div>
    {mode === 'custom' ? <><input type="date" value={rg.from} onChange={e => setRg({ ...rg, from: e.target.value })} /><input type="date" value={rg.to} onChange={e => setRg({ ...rg, to: e.target.value })} /></> : <input type="date" value={date} onChange={e => setDate(e.target.value)} />}
    <button onClick={() => print()}><i className="fa-solid fa-print" /> Imprimer</button></div></div>
    {r && <div className="print"><div className="card"><div className="rep-h"><Logo size={50} /><div><h2>Rapport de stock {TT[mode]}</h2><small>Période : {r.from}{r.to !== r.from && ' au ' + r.to} · édité le {f(new Date())}</small></div></div>
      <div className="grid"><Kpi icon="fa-arrow-down" label="Stock entrant" value={r.totaux.entrees} tone="green" /><Kpi icon="fa-arrow-up" label="Stock sortant" value={r.totaux.sorties} tone="amber" /><Kpi icon="fa-boxes-stacked" label="Stock restant" value={r.totaux.restant} tone="blue" />
        <Kpi icon="fa-coins" label="Prix des stocks vendus" value={money(r.totaux.ca)} /><Kpi icon="fa-chart-line" label="Marge" value={money(r.totaux.marge)} tone={r.totaux.marge >= 0 ? 'green' : 'red'} /><Kpi icon="fa-warehouse" label="Valeur restante" value={money(r.totaux.valeur_restante)} tone="violet" /></div>
      <Sec icon="chart-column" title="Ventes par produit"><Bars raw data={r.produits.filter(p => p.ca > 0).map(p => ({ k: p.produit, ca: p.ca }))} series={[{ key: 'ca', label: 'Prix des stocks vendus', color: accent() }]} /></Sec>
      <Sec icon="table" title="Détail par produit"><table><thead><tr><th>Produit</th><th>Ouverture</th><th>Entrées</th><th>Sorties</th><th>Restant</th><th>Ventes</th><th>Marge</th><th>Valeur restante</th></tr></thead><tbody>
        {r.produits.map(p => <tr key={p.id}><td>{p.produit}</td><td>{p.ouverture}</td><td>{p.entrees}</td><td>{p.sorties}</td><td><b className={p.alerte ? 'neg' : ''}>{p.restant}</b></td><td>{money(p.ca)}</td><td>{money(p.marge)}</td><td>{money(p.valeur_restante)}</td></tr>)}
        {!r.produits.length && <tr><td colSpan="8">Aucun produit.</td></tr>}
        <tr><td><b>TOTAL</b></td><td><b>{r.totaux.ouverture}</b></td><td><b>{r.totaux.entrees}</b></td><td><b>{r.totaux.sorties}</b></td><td><b>{r.totaux.restant}</b></td><td><b>{money(r.totaux.ca)}</b></td><td><b>{money(r.totaux.marge)}</b></td><td><b>{money(r.totaux.valeur_restante)}</b></td></tr></tbody></table></Sec>
      {r.alertes.length > 0 && <Sec icon="triangle-exclamation" title="Produits à réapprovisionner">{r.alertes.map(a => <span className="chip" key={a.id}>{a.produit} : {a.restant} restant (seuil {a.seuil})</span>)}</Sec>}</div></div>}</>;
}

function Label({ p, D, onClose }) {
  const [B, setB] = useState({}), [svg, setSvg] = useState(''), [n, setN] = useState(1);
  useEffect(() => { api('/brand').then(setB).catch(() => { }); QRCode.toString(p.code, { type: 'svg', margin: 0 }).then(setSvg); }, [p.code]);
  const cl = (D.clients || []).find(x => x.id == p.client) || {}, dest = nameOf(D, 'cities', p.ville), copies = Math.max(1, Math.min(50, +n || 1));
  const exp = { nom: p.exp_nom || cl.nom || '—', tel: p.exp_tel || cl.tel || '', ville: p.exp_ville || cl.ville || '' };
  const pay = p.paiement === 'destination' ? `PORT DÛ : ${money(p.montant_dest)}` : p.paiement === 'partiel' ? `PAYÉ ${money(p.montant_ici)} · RESTE ${money(p.montant_dest)}` : 'PAYÉ';
  return <div className="m"><div className="lbl-wrap">
    <div className="bar noprint"><label style={{ display: 'flex', alignItems: 'center', gap: 6 }}>Nombre d'étiquettes (1 par carton)<input type="number" min="1" max="50" value={n} onChange={e => setN(e.target.value)} style={{ width: 70 }} /></label><button className="p" onClick={() => print()}><i className="fa-solid fa-print" /> Imprimer</button><button onClick={onClose}>Fermer</button></div>
    <div className="print">{Array.from({ length: copies }, (_, i) => <div className="label" key={i}>
      <div className="lb-h"><Logo size={34} /><div><b>{B.nom}</b><small>{[B.tel1, B.tel2].filter(Boolean).join(' · ')}</small></div><div className="lb-n">{copies > 1 ? `${i + 1}/${copies}` : ''}</div></div>
      <div className="lb-dest"><small>Destination</small><b>{dest}</b></div>
      <div className="lb-box"><small>Destinataire</small><b>{p.dest}</b><div>{p.tel}</div>{p.adresse_dest && <div>{p.adresse_dest}</div>}<div>{dest}</div></div>
      <div className="lb-box lb-from"><small>Expéditeur</small><b>{exp.nom}</b><div>{[exp.tel, exp.ville].filter(Boolean).join(' · ')}</div></div>
      <div className="lb-row"><div><small>Poids</small><b>{p.poids} kg</b></div><div><small>Catégorie</small><b>{p.categorie === 'cosmetique' ? 'Cosmétique' : 'Simple'}</b></div><div><small>Contenu</small><b>{p.contenu || '—'}</b></div></div>
      <div className="lb-pay">{pay}</div>
      <div className="lb-f"><div className="lb-qr" dangerouslySetInnerHTML={{ __html: svg }} /><div><b className="lb-code">{p.code}</b><small>{p.date}</small></div></div>
      <div className="lb-foot">{[B.slogan, B.website].filter(Boolean).join(' · ')}</div></div>)}</div></div></div>;
}

function Lots() {
  const [L, setL] = useState(null), load = () => api('/lots').then(setL); useEffect(() => { load(); }, []);
  if (!L) return <p>Chargement…</p>;
  return <><Sec icon="weight-hanging" title={`Cumul en cours par destination (seuil : ${L.limit} kg)`}>{L.pending.map(p => <div className="row" key={p.ville}><span style={{ width: 120 }}>{p.nom}</span><progress max={L.limit} value={Math.min(p.poids, L.limit)} /> <span>{p.poids} / {L.limit} kg</span></div>)}{!L.pending.length && <p>Aucun colis en attente d'emballage.</p>}</Sec>
    <div className="card"><table><thead><tr><th>Tas n°</th><th>Date</th><th>Destination</th><th>Colis</th><th>Poids</th><th>État</th><th /></tr></thead><tbody>
      {L.lots.map(l => <tr key={l.id}><td><b>{l.id}</b></td><td>{l.date}</td><td>{l.ville}</td><td>{l.colis}</td><td>{l.poids} kg</td><td>{l.etat}</td><td>{l.etat === 'À emballer' && <button className="p" onClick={async () => { await api('/lots/' + l.id, 'PATCH'); load(); }}>Marquer emballé</button>}</td></tr>)}
      {!L.lots.length && <tr><td colSpan="7">Aucun tas pour le moment.</td></tr>}</tbody></table></div></>;
}
function Reports() {
  const [period, setPeriod] = useState('day'), [date, setDate] = useState(f(new Date())), [r, setR] = useState(null), [cl, setCl] = useState([]);
  const load = () => { api(`/reports?period=${period}&date=${date}`).then(setR); api('/clotures').then(setCl); };
  useEffect(() => { load(); }, [period, date]);
  const T = { day: 'Rapport journalier', week: 'Rapport hebdomadaire', month: 'Rapport mensuel' };
  return <><div className="card noprint"><div className="bar" style={{ margin: 0 }}><div className="tabs">{Object.entries({ day: 'Jour', week: 'Semaine', month: 'Mois' }).map(([k, l]) => <button key={k} className={period === k ? 'on' : ''} onClick={() => setPeriod(k)}>{l}</button>)}</div>
    <input type="date" value={date} onChange={e => setDate(e.target.value)} /><button onClick={() => print()}><i className="fa-solid fa-print" /> Imprimer</button>
    <button onClick={async () => { await api('/clotures', 'POST', { date }); load(); }}><i className="fa-solid fa-lock" /> Clôturer la journée du {date}</button></div></div>
    {r && <div className="print"><div className="card"><div className="rep-h"><Logo size={50} /><div><h2>Parlement Service – {T[period]}</h2><small>Période : {r.from}{r.to !== r.from && ' au ' + r.to} · édité le {f(new Date())}</small></div></div>
      <div className="grid"><Kpi icon="fa-circle-check" label="Colis livrés" value={r.livres} tone="green" /><Kpi icon="fa-weight-hanging" label="Poids livré" value={r.poids + ' kg'} tone="violet" /><Kpi icon="fa-coins" label="Montant total livré" value={money(r.montant)} />
        <Kpi icon="fa-box" label="Colis enregistrés" value={r.crees} tone="blue" /><Kpi icon="fa-hand-holding-dollar" label="Encaissé (colis enregistrés)" value={money(r.encaisse)} tone="green" /><Kpi icon="fa-receipt" label="Dépenses" value={money(r.depenses)} tone="slate" />
        <Kpi icon="fa-chart-line" label="Bénéfice" value={money(r.benefice)} tone={r.benefice >= 0 ? 'green' : 'red'} /><Kpi icon="fa-boxes-packing" label="Tas emballés" value={r.emballes} tone="amber" /></div>
      <Sec icon="chart-column" title="Montant livré par client"><Bars raw data={r.parClient.map(c => ({ k: c.nom, montant: c.montant }))} series={[{ key: 'montant', label: 'Montant livré', color: '#e8761c' }]} /></Sec>
      <Sec icon="users" title="Colis livrés par client"><table><thead><tr><th>Client</th><th>Colis livrés</th><th>Poids</th><th>Montant</th></tr></thead><tbody>
        {r.parClient.map(c => <tr key={c.id}><td>{c.nom}</td><td>{c.colis}</td><td>{c.poids} kg</td><td>{money(c.montant)}</td></tr>)}{!r.parClient.length && <tr><td colSpan="4">Aucune livraison sur la période.</td></tr>}
        <tr><td><b>TOTAL</b></td><td><b>{r.livres}</b></td><td><b>{r.poids} kg</b></td><td><b>{money(r.montant)}</b></td></tr></tbody></table></Sec></div></div>}
    <Sec icon="clock-rotate-left" title="Clôtures journalières automatiques"><table><thead><tr><th>Date</th><th>Colis livrés</th><th>Poids</th><th>Total</th></tr></thead><tbody>{cl.map(c => <tr key={c.id}><td>{c.date}</td><td>{c.livres}</td><td>{c.poids} kg</td><td>{money(c.montant)}</td></tr>)}{!cl.length && <tr><td colSpan="4">Aucune clôture enregistrée.</td></tr>}</tbody></table></Sec></>;
}
function Home({ D, go }) {
  const [s, setS] = useState(null), [L, setL] = useState(null), [F, setF] = useState(null);
  useEffect(() => { api('/stats').then(setS); if (staff()) { api('/lots').then(setL); const x = new Date(); x.setDate(x.getDate() - 13); api(`/finance?from=${f(x)}&to=${f(new Date())}`).then(setF); } }, [D.parcels?.length]);
  if (!s) return <p>Chargement…</p>;
  const hour = new Date().getHours();
  return <><div className="hero"><div><h2>{hour < 18 ? 'Bonjour' : 'Bonsoir'}, bienvenue chez Parlement Service</h2><p>Jours de vols : mardi, jeudi, samedi et dimanche · Dépôt des colis avant 14h.</p></div>
    <div className="bar"><button className="p" onClick={() => go('parcels')}><i className="fa-solid fa-plus" /> Nouveau colis</button>{staff() && <><button onClick={() => go('doc:facture')}><i className="fa-solid fa-file-invoice-dollar" /> Factures</button><button onClick={() => go('finance')}><i className="fa-solid fa-wallet" /> Finance</button></>}</div></div>
    <div className="grid"><Kpi icon="fa-box" label="Colis enregistrés" value={s.total} tone="blue" /><Kpi icon="fa-circle-check" label="Colis livrés" value={s.parStatut['Livré']} tone="green" />
      {staff() && F && <><Kpi icon="fa-coins" label="Chiffre d'affaires (14 j)" value={money(F.ca)} /><Kpi icon="fa-hand-holding-dollar" label="Encaissé (14 j)" value={money(F.encaisse)} tone="green" /><Kpi icon="fa-box-open" label="Colis non envoyés" value={F.groupes.non.colis} sub={money(F.groupes.non.montant)} tone="amber" />
        <Kpi icon="fa-truck-fast" label="En cours d'envoi" value={F.groupes.cours.colis} sub={money(F.groupes.cours.montant)} tone="violet" /><Kpi icon="fa-scale-balanced" label="Résultat net (14 j)" value={money(F.net)} tone={F.net >= 0 ? 'green' : 'red'} /><Kpi icon="fa-users" label="Clients" value={s.counts.clients} tone="slate" /></>}</div>
    <div className="cols">{staff() && F ? <Sec icon="chart-column" title="Activité des 14 derniers jours"><Bars data={F.series} series={[{ key: 'ca', label: "Chiffre d'affaires", color: '#e8761c' }, { key: 'enc', label: 'Encaissé', color: '#16a34a' }, { key: 'dep', label: 'Dépenses', color: '#475569' }]} /></Sec> : <div />}
      <Sec icon="chart-pie" title="Colis par statut"><Donut data={statData(s.parStatut)} center={s.total} /></Sec></div>
    {L && <Sec icon="weight-hanging" title={`Avant le prochain tas de ${L.limit} kg`}>{L.pending.map(p => <div className="row" key={p.ville}><span style={{ width: 120 }}>{p.nom}</span><progress max={L.limit} value={Math.min(p.poids, L.limit)} /> <span>{p.poids} / {L.limit} kg</span></div>)}{!L.pending.length && <p>Aucun colis en attente d'emballage.</p>}</Sec>}</>;
}

export default function App() {
  const [ok, setOk] = useState(!!localStorage.getItem('tk')), [page, setPage] = useState('home'), [D, setD] = useState(null), [B, setB] = useState({}), [openDoc, setOpenDoc] = useState(null);
  const badges = useCallback(() => { if (staff()) api('/badges').then(setB).catch(() => { }); }, []);
  const reload = useCallback(async () => { const L = loadList(), e = await Promise.all(L.map(k => api('/' + k))); setD(Object.fromEntries(L.map((k, i) => [k, e[i]]))); badges(); }, [badges]);
  useEffect(() => { if (ok) reload().catch(() => { }); }, [ok, reload]);
  useEffect(() => { if (!ok) return; const t = setInterval(badges, 20000); return () => clearInterval(t); }, [ok, badges]);
  if (!ok) return <Login onOk={() => setOk(true)} />;
  const openInvoice = async p => { try { if (!p.client) return alert('Ce colis n\'a pas de client : impossible de facturer.');
    const docs = await api('/documents?type=facture'); let d = docs.find(x => x.ref === p.docs?.facture);
    if (!d) { d = await api('/documents', 'POST', { type: 'facture', partie: p.client, ids: [p.id] }); await reload(); } setOpenDoc(d.id); setPage('doc:facture'); } catch (x) { alert(x.message); } };
  const items = MENU.filter(visible).filter(m => staff() || (['home', 'parcels', 'claims', 'modifs', 'etat'].includes(m[0]) && !(role() === 'livreur' && ['claims', 'modifs'].includes(m[0]))));
  const body = !D ? <p>Chargement…</p> : page === 'home' ? <Home D={D} go={setPage} /> : page === 'stats' ? <Stats D={D} /> : page === 'finance' ? <Finance D={D} /> : page === 'stock' ? <Stock D={D} /> : page === 'lots' ? <Lots /> : page === 'reports' ? <Reports />
    : page.startsWith('doc:') ? <DocPage key={page} type={page.slice(4)} D={D} reload={reload} openId={openDoc} clear={() => setOpenDoc(null)} /> : page === 'etat' ? <Track /> : page === 'settings' ? <Settings /> : page === 'notifs' ? <Notifs />
    : <Resource key={page} res={page} D={D} reload={reload} onInvoice={openInvoice} />;
  const title = (items.find(m => m[0] === page) || [])[1];
  return <><aside><h2><Wordmark light /></h2>
    {items.map(([k, l, , ic]) => <a key={k} className={page === k ? 'on' : ''} onClick={() => setPage(k)}><i className={'fa-solid ' + ic} />{l}{B[k] > 0 && <span className="badge">{B[k]}</span>}</a>)}
    <a className="out" onClick={() => { localStorage.clear(); setOk(false); }}><i className="fa-solid fa-right-from-bracket" />Déconnexion</a></aside>
    <main>{staff() && B.lots > 0 && <div className="alert noprint">Alerte : {B.lots} tas atteignant le poids seuil sont à emballer et à compter. <a onClick={() => setPage('lots')}>Voir les tas</a></div>}
      <div className="ph noprint"><div><h1>{title}</h1><small>{new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</small></div><span className="ph-r"><i className="fa-solid fa-user" /> {({ admin: 'Administrateur', agent: 'Agent', livreur: 'Livreur', client: 'Client' })[role()]}</span></div>{body}</main></>;
}
