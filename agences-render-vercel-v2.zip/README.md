# Agences : Render (API) + Vercel (interface) + Neon (base de données)

Chaque dossier est une application : holding, parlement, adjour, tawali.
- `render.yaml` crée les 4 API sur Render (plan gratuit).
- Chaque `<app>/client` se déploie sur Vercel (dossier racine : `<app>/client`, variable `VITE_API_URL` = adresse de l'API Render).
- Les données sont stockées dans une base PostgreSQL (variable `DATABASE_URL`, par exemple Neon). Les 4 applications peuvent partager la même base : chacune utilise sa propre clé (`APP_KEY`).

Comptes administrateur initiaux : holding -> admin@holding.com, parlement -> admin@parlement.com, adjour -> admin@adjourmarket.com, tawali -> admin@tawali.com
(mot de passe = variable ADMIN_PASSWORD, ou `admin123` si elle est vide : à changer dans le menu Utilisateurs).

Test local sans base : `cd holding && npm install && npm start` (http://localhost:4000, données dans un fichier).

## Fonctionnalités ajoutées
- **Gestion de stock** : produits, entrées de stock, sorties / ventes (refusées si le stock est insuffisant), stock restant, prix des stocks vendus, marge, valeur restante, alerte de stock bas, et rapport jour / semaine / mois / période (imprimable).
- **Étiquettes** : bouton « Étiquette » sur chaque colis (format 100 x 150 mm, QR code du suivi, expéditeur, destinataire, poids, mode de paiement, nombre d'étiquettes = nombre de cartons). Champs ajoutés au colis : expéditeur (par défaut le client), adresse du destinataire, nature du contenu.
