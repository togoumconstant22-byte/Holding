// Point d'entrée attendu par Hostinger (détecté automatiquement : server.js)
import './server/index.js';
