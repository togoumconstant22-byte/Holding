# Adjour Market – Gestion des colis (React + Node.js)
Démarrage local : `npm run install:all`, puis `npm run dev:server` et `npm run dev:client` (http://localhost:5173).
Connexion : admin@adjourmarket.com / admin123 (à changer ; définir JWT_SECRET en production).
